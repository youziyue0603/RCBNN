bash experiments/cifar-100.sh
bash experiments/imagenet-r.sh
bash experiments/imagenet-r_short.sh
bash experiments/imagenet-r_long.sh
bash experiments/domainnet.sh