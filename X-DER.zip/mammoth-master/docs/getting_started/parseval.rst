.. _module-parseval:

Mammoth parseval
================

.. admonition:: TO BE CONTINUED!
    :class: tip

    To be written