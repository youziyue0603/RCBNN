"""
This package contains utility functions for the DualPrompt model. Implements a custom version of ViT to add prompt parameters.
"""
