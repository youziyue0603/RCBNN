"""
Utility functions for SLCA model. Implements custom backbones, including ViT and ResNet.
"""
