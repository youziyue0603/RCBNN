This project is licensed under the MIT License. However, some files in this repository are under the Apache 2.0 License as noted below:

- backbone/vit.py (Apache 2.0 License)
- models/l2p.py (Apache 2.0 License)
- models/dualprompt.py (Apache 2.0 License)