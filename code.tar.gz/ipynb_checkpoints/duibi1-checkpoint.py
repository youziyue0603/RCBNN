#!/usr/bin/env python3
"""
Complete CODA-Prompt Implementation for Continual Learning
A self-contained implementation that can be run directly
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset, Subset
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
from typing import List, Dict, Tuple, Optional
import json
import os
from tqdm import tqdm

# Set random seeds for reproducibility
torch.manual_seed(42)
np.random.seed(42)

class CODAPrompt(nn.Module):
    """
    CODA-Prompt: COntinual Decomposed Attention-based Prompting
    for Rehearsal-Free Continual Learning
    """
    
    def __init__(
        self,
        embed_dim: int = 768,
        prompt_length: int = 8,
        num_components: int = 100,
        num_layers: int = 12,
        prompt_layers: List[int] = [0, 1, 2, 3, 4],
        ortho_lambda: float = 0.1,
        device: str = 'cuda'
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.prompt_length = prompt_length
        self.num_components = num_components
        self.num_layers = num_layers
        self.prompt_layers = prompt_layers
        self.ortho_lambda = ortho_lambda
        self.device = device
        
        # Current task tracking
        self.current_task = 0
        self.components_per_task = max(1, num_components // 10)  # Assume max 10 tasks initially
        
        # Initialize prompt components for each layer
        
        self.prompt_components = nn.ParameterDict()
        self.prompt_keys = nn.ParameterDict() 
        self.attention_vectors = nn.ParameterDict()
        for layer_idx in prompt_layers:
            # Prompt components P ∈ R^{L_p × D × M}
            self.prompt_components[f'layer_{layer_idx}'] = nn.Parameter(
                torch.randn(prompt_length, embed_dim, num_components) * 0.01
            )
            
            # Keys K ∈ R^{D × M}
            self.prompt_keys[f'layer_{layer_idx}'] = nn.Parameter(
                torch.randn(embed_dim, num_components) * 0.01
            )
            
            # Attention vectors A ∈ R^{D × M}
            self.attention_vectors[f'layer_{layer_idx}'] = nn.Parameter(
                torch.randn(embed_dim, num_components) * 0.01
            )
        
        # Orthogonal initialization
        self._init_orthogonal()
        
        # Track frozen components
        self.frozen_components = set()

    def _init_orthogonal(self):
        """Initialize parameters with orthogonal constraint"""
        for layer_idx in self.prompt_layers:
            # Orthogonal initialization for components
            components = self.prompt_components[f'layer_{layer_idx}']
            for i in range(components.shape[-1]):
                if components.shape[0] >= components.shape[1]:
                    nn.init.orthogonal_(components[:, :, i])
            
            # Orthogonal initialization for keys and attention vectors
            nn.init.orthogonal_(self.prompt_keys[f'layer_{layer_idx}'])
            nn.init.orthogonal_(self.attention_vectors[f'layer_{layer_idx}'])

    def cosine_similarity(self, query: torch.Tensor, keys: torch.Tensor) -> torch.Tensor:
        """
        Compute cosine similarity between query and keys
        Args:
            query: [batch_size, embed_dim]
            keys: [embed_dim, num_components]
        Returns:
            similarities: [batch_size, num_components]
        """
        # Normalize query and keys
        query_norm = F.normalize(query, dim=-1)  # [B, D]
        keys_norm = F.normalize(keys, dim=0)     # [D, M]
        
        # Compute cosine similarity
        similarities = torch.matmul(query_norm, keys_norm)  # [B, M]
        return similarities

    def compute_component_weights(
        self, 
        query: torch.Tensor, 
        layer_idx: int
    ) -> torch.Tensor:
        """
        Compute attention-based component weights
        Args:
            query: [batch_size, embed_dim]
            layer_idx: layer index
        Returns:
            weights: [batch_size, num_components]
        """
        # Get attention vectors and keys for this layer
        attention_vecs = self.attention_vectors[f'layer_{layer_idx}']  # [D, M]
        keys = self.prompt_keys[f'layer_{layer_idx}']                # [D, M]

        # Apply attention: q(x) ⊙ A (element-wise multiplication)
        # Broadcast query to match attention vectors
        attended_query = query.unsqueeze(-1) * attention_vecs.unsqueeze(0)  # [B, D, M]

        # 修改这部分：不要sum，而是直接计算余弦相似度
        # attended_query = attended_query.sum(dim=1)  # 删除这一行

        # Compute cosine similarity with keys
        # keys: [D, M] -> [1, D, M]
        keys_expanded = keys.unsqueeze(0)  # [1, D, M]

        # 计算余弦相似度：attended_query [B, D, M], keys_expanded [1, D, M]
        weights = F.cosine_similarity(attended_query, keys_expanded, dim=1)  # [B, M]

        # Apply softmax to get normalized weights
        weights = F.softmax(weights, dim=-1)

        return weights

    def generate_prompts(
        self, 
        query: torch.Tensor, 
        layer_idx: int
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Generate prompts for a specific layer using decomposed components
        Args:
            query: [batch_size, embed_dim] - query from ViT encoder
            layer_idx: transformer layer index
        Returns:
            prompt_key: [batch_size, prompt_length//2, embed_dim]
            prompt_value: [batch_size, prompt_length//2, embed_dim]
        """
        batch_size = query.shape[0]
        
        # Get component weights using attention mechanism
        weights = self.compute_component_weights(query, layer_idx)  # [B, M]
        
        # Get prompt components for this layer
        components = self.prompt_components[f'layer_{layer_idx}']  # [L_p, D, M]
        
        # Weighted combination of components: p = Σ α_m * P_m
        # weights: [B, M], components: [L_p, D, M]
        weighted_prompts = torch.einsum('bm,ldm->bld', weights, components)  # [B, L_p, D]
        
        # Split prompt into key and value parts (prefix tuning)
        prompt_len_half = self.prompt_length // 2
        prompt_key = weighted_prompts[:, :prompt_len_half, :]     # [B, L_p/2, D]
        prompt_value = weighted_prompts[:, prompt_len_half:, :]   # [B, L_p/2, D]
        
        return prompt_key, prompt_value

    def forward(
        self, 
        query: torch.Tensor, 
        layer_idx: int
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass to generate prompts
        Args:
            query: [batch_size, embed_dim]
            layer_idx: layer index
        Returns:
            prompt_key, prompt_value for prefix tuning
        """
        if f'layer_{layer_idx}' not in self.prompt_components:
            # Return empty prompts if layer not in prompt_layers
            batch_size = query.shape[0]
            empty_prompt = torch.zeros(
                batch_size, self.prompt_length // 2, self.embed_dim,
                device=query.device
            )
            return empty_prompt, empty_prompt
        
        return self.generate_prompts(query, layer_idx)

    def expand_for_new_task(self):
        """
        Expand components for new task and freeze previous components
        """
        # Freeze current components
        start_idx = self.current_task * self.components_per_task
        end_idx = (self.current_task + 1) * self.components_per_task
        
        for i in range(start_idx, min(end_idx, self.num_components)):
            self.frozen_components.add(i)
        
        self.current_task += 1

    def compute_orthogonality_loss(self) -> torch.Tensor:
        """
        Compute orthogonality regularization loss
        Returns:
            ortho_loss: scalar tensor
        """
        total_loss = 0.0
        
        for layer_idx in self.prompt_layers:
            layer_key = f'layer_{layer_idx}'
            
            # Orthogonality loss for prompt components
            components = self.prompt_components[layer_key]  # [L_p, D, M]
            # Reshape to [L_p*D, M] for orthogonality computation
            comp_flat = components.view(-1, components.shape[-1])  # [L_p*D, M]
            comp_gram = torch.matmul(comp_flat.T, comp_flat)  # [M, M]
            identity = torch.eye(comp_gram.shape[0], device=comp_gram.device)
            comp_loss = torch.norm(comp_gram - identity) ** 2
            
            # Orthogonality loss for keys
            keys = self.prompt_keys[layer_key]  # [D, M]
            key_gram = torch.matmul(keys.T, keys)  # [M, M]
            identity_k = torch.eye(key_gram.shape[0], device=key_gram.device)
            key_loss = torch.norm(key_gram - identity_k) ** 2
            
            # Orthogonality loss for attention vectors
            attn = self.attention_vectors[layer_key]  # [D, M]
            attn_gram = torch.matmul(attn.T, attn)  # [M, M]
            identity_a = torch.eye(attn_gram.shape[0], device=attn_gram.device)
            attn_loss = torch.norm(attn_gram - identity_a) ** 2
            
            total_loss += comp_loss + key_loss + attn_loss
        
        return total_loss

    def get_num_parameters(self) -> int:
        """Get total number of parameters"""
        return sum(p.numel() for p in self.parameters())


class SimpleViTLayer(nn.Module):
    """Simplified ViT layer for demonstration"""
    
    def __init__(self, embed_dim, num_heads, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(embed_dim)
        self.attn = nn.MultiheadAttention(embed_dim, num_heads, dropout=dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(embed_dim)
        
        mlp_hidden_dim = int(embed_dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, mlp_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_hidden_dim, embed_dim),
            nn.Dropout(dropout)
        )
    
    def forward(self, x, prompt_key=None, prompt_value=None):
        # Self-attention with optional prompts
        x_norm = self.norm1(x)
        
        if prompt_key is not None and prompt_value is not None:
            # Concatenate prompts (simplified prefix tuning)
            batch_size, seq_len, embed_dim = x_norm.shape
            prompt_len = prompt_key.shape[1]
            
            # Create combined input with prompts
            prompt_tokens = (prompt_key + prompt_value) / 2  # Simple combination
            x_with_prompts = torch.cat([prompt_tokens, x_norm], dim=1)
            
            # Self-attention
            attn_out, _ = self.attn(x_with_prompts, x_with_prompts, x_with_prompts)
            
            # Remove prompt tokens from output
            attn_out = attn_out[:, prompt_len:, :]
        else:
            attn_out, _ = self.attn(x_norm, x_norm, x_norm)
        
        # Residual connection
        x = x + attn_out
        
        # MLP
        x = x + self.mlp(self.norm2(x))
        
        return x


class ViTWithCODAPrompt(nn.Module):
    """
    Vision Transformer with CODA-Prompt integration
    Simplified ViT implementation for demonstration
    """
    
    def __init__(
        self,
        image_size: int = 224,
        patch_size: int = 16,
        embed_dim: int = 384,  # Smaller for efficiency
        num_heads: int = 6,
        num_layers: int = 12,
        num_classes: int = 100,
        prompt_config: Dict = None
    ):
        super().__init__()
        
        self.patch_size = patch_size
        self.embed_dim = embed_dim
        self.num_patches = (image_size // patch_size) ** 2
        
        # Patch embedding
        self.patch_embed = nn.Conv2d(3, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.pos_embed = nn.Parameter(torch.randn(1, self.num_patches + 1, embed_dim) * 0.02)
        self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim) * 0.02)
        
        # Transformer layers
        self.layers = nn.ModuleList([
            SimpleViTLayer(embed_dim, num_heads, mlp_ratio=4.0, dropout=0.1) 
            for _ in range(num_layers)
        ])
        
        # CODA-Prompt
        if prompt_config is None:
            prompt_config = {}
        
        prompt_config['embed_dim'] = embed_dim
        self.coda_prompt = CODAPrompt(**prompt_config)
        
        # Classification head
        self.classifier = nn.Linear(embed_dim, num_classes)
        self.dropout = nn.Dropout(0.1)
        
        # Layer normalization
        self.norm = nn.LayerNorm(embed_dim)
        
    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        """Extract features using ViT with CODA prompts"""
        batch_size = x.shape[0]
        
        # Patch embedding
        x = self.patch_embed(x)  # [B, embed_dim, H//patch_size, W//patch_size]
        x = x.flatten(2).transpose(1, 2)  # [B, num_patches, embed_dim]
        
        # Add class token
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat([cls_tokens, x], dim=1)  # [B, num_patches+1, embed_dim]
        
        # Add position embedding
        x = x + self.pos_embed
        
        # Get query for prompt generation (from cls token)
        query = x[:, 0, :]  # [B, embed_dim]
        
        # Forward through transformer layers with prompts
        for i, layer in enumerate(self.layers):
            
            if i in self.coda_prompt.prompt_layers:
                # Generate prompts for this layer
                prompt_key, prompt_value = self.coda_prompt(query, i)
                x = layer(x, prompt_key, prompt_value)
            else:
                x = layer(x)
        
        x = self.norm(x)
        return x[:, 0]  # Return cls token

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass"""
        features = self.forward_features(x)
        logits = self.classifier(self.dropout(features))
        return logits

    def get_query(self, x: torch.Tensor) -> torch.Tensor:
        """Get query vector for prompt generation"""
        batch_size = x.shape[0]
        
        # Patch embedding
        x = self.patch_embed(x)
        x = x.flatten(2).transpose(1, 2)
        
        # Add class token and position embedding
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat([cls_tokens, x], dim=1)
        x = x + self.pos_embed
        
        return x[:, 0, :]  # Return cls token representation


class ContinualLearner:
    """
    Continual Learning trainer for CODA-Prompt
    """
    
    def __init__(
        self,
        model: ViTWithCODAPrompt,
        learning_rate: float = 1e-3,
        ortho_lambda: float = 0.1,
        device: str = 'cuda'
    ):
        self.model = model.to(device)
        self.device = device
        self.ortho_lambda = ortho_lambda
        
        # Optimizer - only optimize prompt parameters and classifier
        prompt_params = list(self.model.coda_prompt.parameters())
        classifier_params = list(self.model.classifier.parameters())
        self.optimizer = torch.optim.Adam(
            prompt_params + classifier_params, 
            lr=learning_rate,
            betas=(0.9, 0.999)
        )
        
        # Loss function
        self.criterion = nn.CrossEntropyLoss()
        
        # Metrics tracking
        self.task_accuracies = []
        self.forgetting_metrics = []
        
    def train_task(
        self, 
        train_loader, 
        task_id: int,
        epochs: int = 20,
        verbose: bool = True
    ):
        """Train on a new task"""
        
        if task_id > 0:
            # Expand components for new task
            self.model.coda_prompt.expand_for_new_task()
        
        self.model.train()
        
        for epoch in range(epochs):
            total_loss = 0.0
            total_ortho_loss = 0.0
            correct = 0
            total = 0
            
            progress_bar = tqdm(train_loader, desc=f'Task {task_id}, Epoch {epoch+1}/{epochs}') if verbose else train_loader
            
            for batch_idx, (data, targets) in enumerate(progress_bar):
                data, targets = data.to(self.device), targets.to(self.device)
                
                self.optimizer.zero_grad()
                
                # Forward pass
                logits = self.model(data)
                
                # Classification loss
                cls_loss = self.criterion(logits, targets)
                
                # Orthogonality regularization loss
                ortho_loss = self.model.coda_prompt.compute_orthogonality_loss()
                
                # Total loss
                loss = cls_loss + self.ortho_lambda * ortho_loss
                
                # Backward pass
                loss.backward()
                self.optimizer.step()
                
                # Statistics
                total_loss += cls_loss.item()
                total_ortho_loss += ortho_loss.item()
                
                predicted = logits.argmax(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
                
                if verbose:
                    progress_bar.set_postfix({
                        'Loss': f'{cls_loss.item():.4f}',
                        'Ortho': f'{ortho_loss.item():.4f}',
                        'Acc': f'{100.*correct/total:.2f}%'
                    })
            
            if verbose:
                acc = 100. * correct / total
                avg_loss = total_loss / len(train_loader)
                avg_ortho = total_ortho_loss / len(train_loader)
                print(f'Task {task_id}, Epoch {epoch+1}/{epochs}: '
                      f'Loss: {avg_loss:.4f}, Ortho: {avg_ortho:.4f}, Acc: {acc:.2f}%')

    def evaluate_task(self, test_loader, task_id: int) -> float:
        """Evaluate on a specific task"""
        self.model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for data, targets in test_loader:
                data, targets = data.to(self.device), targets.to(self.device)
                
                logits = self.model(data)
                predicted = logits.argmax(1)
                
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
        
        accuracy = 100. * correct / total
        return accuracy

    def evaluate_all_tasks(self, test_loaders: List) -> Dict[str, float]:
        """Evaluate on all seen tasks"""
        accuracies = []
        
        for task_id, test_loader in enumerate(test_loaders):
            acc = self.evaluate_task(test_loader, task_id)
            accuracies.append(acc)
        
        # Calculate metrics
        avg_accuracy = np.mean(accuracies)
        
        # Calculate forgetting (if we have previous accuracies)
        if len(self.task_accuracies) > 0:
            forgetting = []
            for i in range(len(self.task_accuracies[-1])):
                max_acc = max([acc_list[i] for acc_list in self.task_accuracies])
                current_acc = accuracies[i]
                forgetting.append(max_acc - current_acc)
            avg_forgetting = np.mean(forgetting[:-1]) if len(forgetting) > 1 else 0.0
        else:
            avg_forgetting = 0.0
        
        self.task_accuracies.append(accuracies.copy())
        self.forgetting_metrics.append(avg_forgetting)
        
        return {
            'individual_accuracies': accuracies,
            'average_accuracy': avg_accuracy,
            'average_forgetting': avg_forgetting
        }


class ContinualCIFAR100Dataset:
    """
    CIFAR-100 dataset split into continual learning tasks
    """
    
    def __init__(self, root='./data', num_tasks=5, download=True):
        self.root = root
        self.num_tasks = num_tasks
        self.classes_per_task = 100 // num_tasks
        
        # Define transforms - simpler transforms to avoid issues
        self.train_transform = transforms.Compose([
            transforms.Resize(224),  # Resize for ViT
            transforms.ToTensor(),
            transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        ])
        
        self.test_transform = transforms.Compose([
            transforms.Resize(224),
            transforms.ToTensor(),
            transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        ])
        
        # Load CIFAR-100 with transforms=None first
        train_dataset_no_transform = torchvision.datasets.CIFAR100(
            root=root, train=True, download=download, transform=None
        )
        
        test_dataset_no_transform = torchvision.datasets.CIFAR100(
            root=root, train=False, download=download, transform=None
        )
        
        # Create task splits
        self.task_train_datasets = []
        self.task_test_datasets = []
        
        for task_id in range(num_tasks):
            start_class = task_id * self.classes_per_task
            end_class = (task_id + 1) * self.classes_per_task
            
            # Filter datasets by class
            train_data = []
            train_labels = []
            test_data = []
            test_labels = []
            
            for i in range(len(train_dataset_no_transform)):
                _, label = train_dataset_no_transform[i]
                if start_class <= label < end_class:
                    train_data.append(train_dataset_no_transform.data[i])
                    train_labels.append(label)
            
            for i in range(len(test_dataset_no_transform)):
                _, label = test_dataset_no_transform[i]
                if start_class <= label < end_class:
                    test_data.append(test_dataset_no_transform.data[i])
                    test_labels.append(label)
            
            # Create task-specific datasets
            task_train = TaskDataset(train_data, train_labels, self.train_transform)
            task_test = TaskDataset(test_data, test_labels, self.test_transform)
            
            self.task_train_datasets.append(task_train)
            self.task_test_datasets.append(task_test)

    def get_task_loaders(self, task_id: int, batch_size: int = 32):
        """Get train and test loaders for a specific task"""
        train_loader = DataLoader(
            self.task_train_datasets[task_id], 
            batch_size=batch_size, 
            shuffle=True,
            num_workers=2,
            pin_memory=True
        )
        
        test_loader = DataLoader(
            self.task_test_datasets[task_id], 
            batch_size=batch_size, 
            shuffle=False,
            num_workers=2,
            pin_memory=True
        )
        
        return train_loader, test_loader

    def get_all_test_loaders(self, batch_size: int = 32):
        """Get test loaders for all tasks"""
        test_loaders = []
        for task_id in range(self.num_tasks):
            _, test_loader = self.get_task_loaders(task_id, batch_size)
            test_loaders.append(test_loader)
        return test_loaders


class TaskDataset(Dataset):
    """Custom dataset for task-specific data"""
    
    def __init__(self, data, labels, transform=None):
        self.data = data
        self.labels = labels
        self.transform = transform
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        from PIL import Image
        
        # Convert numpy array to PIL Image
        image = Image.fromarray(self.data[idx])
        label = self.labels[idx]
        
        if self.transform:
            image = self.transform(image)
            
        return image, label


class CODAPromptExperiment:
    """
    Complete experiment setup for CODA-Prompt continual learning
    """
    
    def __init__(self, config: Dict):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Initialize dataset
        self.dataset = ContinualCIFAR100Dataset(
            root=config['data_root'],
            num_tasks=config['num_tasks']
        )
        
        # Initialize model
        self.model = ViTWithCODAPrompt(
            image_size=224,
            patch_size=16,
            embed_dim=config['embed_dim'],
            num_heads=config['embed_dim'] // 64,  # Standard ratio
            num_layers=6,  # Smaller for efficiency
            num_classes=100,  # CIFAR-100 has 100 classes
            prompt_config={
                'embed_dim': config['embed_dim'],
                'prompt_length': config['prompt_length'],
                'num_components': config['num_components'],
                'prompt_layers': config['prompt_layers'],
                'ortho_lambda': config['ortho_lambda']
            }
        )
        
        # Initialize learner
        self.learner = ContinualLearner(
            model=self.model,
            learning_rate=config['learning_rate'],
            ortho_lambda=config['ortho_lambda'],
            device=self.device
        )
        
        # Results storage
        self.results = {
            'task_accuracies': [],
            'average_accuracies': [],
            'forgetting_metrics': [],
            'config': config
        }

    def run_experiment(self):
        """Run the complete continual learning experiment"""
        print(f"Starting CODA-Prompt experiment on {self.device}")
        print(f"Model parameters: {sum(p.numel() for p in self.model.parameters()):,}")
        print(f"Prompt parameters: {self.model.coda_prompt.get_num_parameters():,}")
        print("=" * 60)
        
        all_test_loaders = self.dataset.get_all_test_loaders(
            batch_size=self.config['batch_size']
        )
        
        for task_id in range(self.config['num_tasks']):
            print(f"\nTraining on Task {task_id + 1}/{self.config['num_tasks']}")
            print("-" * 30)
            
            # Get task data loaders
            train_loader, _ = self.dataset.get_task_loaders(
                task_id, batch_size=self.config['batch_size']
            )
            
            # Train on current task
            self.learner.train_task(
                train_loader=train_loader,
                task_id=task_id,
                epochs=self.config['epochs_per_task'],
                verbose=True
            )
            
            # Evaluate on all tasks seen so far
            print(f"\nEvaluating after Task {task_id + 1}")
            print("-" * 30)
            
            test_loaders_so_far = all_test_loaders[:task_id+1]
            metrics = self.learner.evaluate_all_tasks(test_loaders_so_far)
            
            # Store results
            self.results['task_accuracies'].append(metrics['individual_accuracies'])
            self.results['average_accuracies'].append(metrics['average_accuracy'])
            self.results['forgetting_metrics'].append(metrics['average_forgetting'])
            
            # Print results
            print(f"Individual task accuracies: {[f'{acc:.2f}' for acc in metrics['individual_accuracies']]}")
            print(f"Average accuracy: {metrics['average_accuracy']:.2f}%")
            print(f"Average forgetting: {metrics['average_forgetting']:.2f}%")
            
            print("=" * 60)
        
        # Final results summary
        self.print_final_results()
        return self.results

    def print_final_results(self):
        """Print final experiment results"""
        print("\nFINAL RESULTS")
        print("=" * 60)
        
        final_accuracies = self.results['task_accuracies'][-1]
        final_avg_acc = self.results['average_accuracies'][-1]
        final_forgetting = self.results['forgetting_metrics'][-1]
        
        print(f"Final accuracy per task: {[f'{acc:.2f}' for acc in final_accuracies]}")
        print(f"Final average accuracy: {final_avg_acc:.2f}%")
        print(f"Final average forgetting: {final_forgetting:.2f}%")
        
        # Calculate additional metrics
        print(f"\nAdditional Metrics:")
        print(f"Best average accuracy: {max(self.results['average_accuracies']):.2f}%")
        print(f"Standard deviation of final accuracies: {np.std(final_accuracies):.2f}%")

    def plot_results(self, save_path: str = None):
        """Plot experiment results"""
        try:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
            
            # Plot average accuracy over tasks
            ax1.plot(range(1, len(self.results['average_accuracies']) + 1), 
                    self.results['average_accuracies'], 'b-o', linewidth=2)
            ax1.set_xlabel('Task Number')
            ax1.set_ylabel('Average Accuracy (%)')
            ax1.set_title('Average Accuracy After Each Task')
            ax1.grid(True, alpha=0.3)
            
            # Plot forgetting over tasks
            if len(self.results['forgetting_metrics']) > 1:
                ax2.plot(range(2, len(self.results['forgetting_metrics']) + 1), 
                        self.results['forgetting_metrics'][1:], 'r-s', linewidth=2)
                ax2.set_xlabel('Task Number')
                ax2.set_ylabel('Average Forgetting (%)')
                ax2.set_title('Average Forgetting After Each Task')
                ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"Results plot saved to {save_path}")
            
            plt.show()
        except Exception as e:
            print(f"Could not create plot: {e}")

    def save_results(self, save_path: str):
        """Save experiment results to file"""
        try:
            with open(save_path, 'w') as f:
                json.dump(self.results, f, indent=2)
            print(f"Results saved to {save_path}")
        except Exception as e:
            print(f"Could not save results: {e}")


def create_experiment_config():
    """Create default experiment configuration"""
    config = {
        # Data settings
        'data_root': './data',
        'num_tasks': 5,
        'batch_size': 16,  # Smaller batch size for memory efficiency
        
        # Model settings
        'embed_dim': 384,  # Smaller ViT for efficiency
        'prompt_length': 8,
        'num_components': 50,  # Reduced for efficiency
        'prompt_layers': [0, 1, 2],  # Fewer layers with prompts
        
        # Training settings
        'epochs_per_task': 10,  # Reduced for demo
        'learning_rate': 1e-3,
        'ortho_lambda': 0.1,
        
        # Experiment settings
        'seed': 42,
        'save_results': True,
        'plot_results': True
    }
    return config


def run_coda_prompt_experiment():
    """Run a complete CODA-Prompt continual learning experiment"""
    
    # Set random seed for reproducibility
    torch.manual_seed(42)
    np.random.seed(42)
    
    # Create experiment configuration
    config = create_experiment_config()
    
    print("CODA-Prompt Continual Learning Experiment")
    print("=" * 60)
    print("Configuration:")
    for key, value in config.items():
        print(f"  {key}: {value}")
    print("=" * 60)
    
    try:
        # Create and run experiment
        experiment = CODAPromptExperiment(config)
        results = experiment.run_experiment()
        
        # Save and plot results
        if config['save_results']:
            experiment.save_results('coda_prompt_results.json')
        
        if config['plot_results']:
            experiment.plot_results('coda_prompt_results.png')
        
        return results
    
    except Exception as e:
        print(f"Experiment failed: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    print("Starting CODA-Prompt 5-task continual learning experiment...")
    
    # 使用默认的5任务配置
    results = run_coda_prompt_experiment()
    
    if results:
        print("\nExperiment completed successfully!")
        print("Final Results Summary:")
        print("-" * 40)
        
        final_accuracies = results['task_accuracies'][-1]
        final_avg_acc = results['average_accuracies'][-1] 
        final_forgetting = results['forgetting_metrics'][-1]
        
        for i, acc in enumerate(final_accuracies):
            print(f"Task {i+1} accuracy: {acc:.2f}%")
        
        print(f"\nOverall Performance:")
        print(f"Average accuracy: {final_avg_acc:.2f}%")
        print(f"Average forgetting: {final_forgetting:.2f}%")
        
        # 展示学习过程
        print(f"\nLearning Progress:")
        for i, avg_acc in enumerate(results['average_accuracies']):
            print(f"After Task {i+1}: {avg_acc:.2f}% average accuracy")
    else:
        print("Experiment failed!")