# -*- coding: utf-8 -*-
# @Time    : 2021/12/22 2:09 下午
# @Author  : Yushuo Wang
# @FileName: plotTheLoss.py
# @Software: PyCharm
# @Blog    ：https://lesliewongcv.github.io/


import matplotlib.pyplot as plt
import numpy as np


f = open('npresult.txt')
lines = f.readlines()
titles_ = ['nll loss of training samples', 'kld loss of training samples', 'nll loss of valid samples', 'pr loss of valid samples']
# titles = ['nll loss of valid samples', 'pr loss of valid samples']
for i in range(4):
    plt.title(titles_[i])
    plt.plot(np.arange(len(lines[i].split())), [float(_) for _ in lines[i].split()])
    plt.savefig(titles_[i] + '.png')
    plt.show()


f = open('npresultT.txt')
lines = f.readlines()
titles = ['kld loss of training samples', 'nll loss of training samples']
for i in range(2):
    plt.title(titles[i])
    plt.plot(np.arange(len(lines[i].split())), [float(_) for _ in lines[i].split()])
    plt.savefig(titles[i] + '.jpg')
    plt.show()


_ = 1