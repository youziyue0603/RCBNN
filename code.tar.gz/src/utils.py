import os
import sys
import time
import numpy as np
import torch
from datetime import datetime


def print_arguments(args):
    """Print all arguments"""
    print('=' * 100)
    print('Arguments =')
    for arg in vars(args):
        print('\t' + arg + ':', getattr(args, arg))
    print('=' * 100)


def make_directories(args):
    """Create necessary directories and return checkpoint path"""

    # Create output directory based on experiment settings
    if not args.output:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_name = f"{args.experiment}_{args.approach}_{args.arch}_seed{args.seed}_{timestamp}"
        args.output = output_name

    # Create directories
    os.makedirs(args.checkpoint_dir, exist_ok=True)

    checkpoint_path = os.path.join(args.checkpoint_dir, args.output)
    os.makedirs(checkpoint_path, exist_ok=True)

    return checkpoint_path


def print_log_acc_bwt(args, acc, lss):
    """Print accuracy and backward transfer results"""
    print('*' * 100)
    print('Accuracies =')
    for i in range(acc.shape[0]):
        print('\t', end='')
        for j in range(acc.shape[1]):
            print('{:5.4f}% '.format(100 * acc[i, j]), end='')
        print()

    print('*' * 100)
    print('Losses =')
    for i in range(lss.shape[0]):
        print('\t', end='')
        for j in range(lss.shape[1]):
            print('{:5.4f} '.format(lss[i, j]), end='')
        print()

    # Calculate average accuracy and backward transfer
    avg_acc = []
    backward_transfer = []

    for t in range(acc.shape[0]):
        # Average accuracy up to task t
        avg_acc.append(np.mean(acc[t, :t + 1]))

        # Backward transfer for task t (if t > 0)
        if t > 0:
            bwt = acc[t, :t].mean() - np.diag(acc)[:t].mean()
            backward_transfer.append(bwt)

    print('*' * 100)
    print('Average Accuracy =')
    for i, avg in enumerate(avg_acc):
        print(f'Task {i}: {100 * avg:.2f}%')
    print(f'Final Average Accuracy: {100 * avg_acc[-1]:.2f}%')

    if backward_transfer:
        print('*' * 100)
        print('Backward Transfer =')
        final_bwt = np.mean(backward_transfer)
        print(f'Average BWT: {100 * final_bwt:.2f}%')

    print('*' * 100)


def save_checkpoint(model, optimizer, epoch, loss, path, filename='checkpoint.pth'):
    """Save model checkpoint"""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'loss': loss,
    }

    os.makedirs(path, exist_ok=True)
    filepath = os.path.join(path, filename)
    torch.save(checkpoint, filepath)
    print(f'Checkpoint saved: {filepath}')


def load_checkpoint(model, optimizer, path, filename='checkpoint.pth'):
    """Load model checkpoint"""
    filepath = os.path.join(path, filename)

    if os.path.exists(filepath):
        checkpoint = torch.load(filepath)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        epoch = checkpoint['epoch']
        loss = checkpoint['loss']
        print(f'Checkpoint loaded: {filepath}')
        return epoch, loss
    else:
        print(f'No checkpoint found at: {filepath}')
        return 0, float('inf')


def get_model_size(model):
    """Calculate model size in parameters"""
    param_size = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()

    buffer_size = 0
    for buffer in model.buffers():
        buffer_size += buffer.nelement() * buffer.element_size()

    size_all_mb = (param_size + buffer_size) / 1024 ** 2

    num_params = sum(p.numel() for p in model.parameters())
    num_trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

    return {
        'size_mb': size_all_mb,
        'num_params': num_params,
        'num_trainable_params': num_trainable_params
    }


def set_seed(seed):
    """Set random seeds for reproducibility"""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def get_device(device_id='cuda:0'):
    """Get the appropriate device"""
    if torch.cuda.is_available() and 'cuda' in device_id:
        device = torch.device(device_id)
        print(f'Using GPU: {device}')
    else:
        device = torch.device('cpu')
        print('Using CPU')

    return device


def print_model_info(model, input_size=None):
    """Print model information"""
    print('=' * 100)
    print('Model Information:')

    # Model architecture
    print('Architecture:')
    print(model)

    # Model size
    model_info = get_model_size(model)
    print(f'\nModel Size: {model_info["size_mb"]:.2f} MB')
    print(f'Total Parameters: {model_info["num_params"]:,}')
    print(f'Trainable Parameters: {model_info["num_trainable_params"]:,}')

    # Forward pass test (if input size provided)
    if input_size is not None:
        model.eval()
        with torch.no_grad():
            dummy_input = torch.randn(1, *input_size)
            if next(model.parameters()).is_cuda:
                dummy_input = dummy_input.cuda()

            try:
                output = model(dummy_input)
                if isinstance(output, (list, tuple)):
                    print(f'\nOutput shapes: {[o.shape for o in output]}')
                else:
                    print(f'\nOutput shape: {output.shape}')
            except Exception as e:
                print(f'\nCould not perform forward pass: {e}')

    print('=' * 100)


def create_exp_dir(path, scripts_to_save=None):
    """Create experiment directory and save scripts"""
    if not os.path.exists(path):
        os.makedirs(path)
    print('Experiment dir: {}'.format(path))

    if scripts_to_save is not None:
        script_path = os.path.join(path, 'scripts')
        if not os.path.exists(script_path):
            os.makedirs(script_path)
        for script in scripts_to_save:
            dst_file = os.path.join(script_path, os.path.basename(script))
            if os.path.exists(script):
                import shutil
                shutil.copyfile(script, dst_file)


class AverageMeter:
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


class Timer:
    """Simple timer class"""

    def __init__(self):
        self.start_time = None
        self.end_time = None

    def start(self):
        self.start_time = time.time()

    def stop(self):
        self.end_time = time.time()

    def elapsed(self):
        if self.start_time is None:
            return 0
        if self.end_time is None:
            return time.time() - self.start_time
        return self.end_time - self.start_time

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.stop()