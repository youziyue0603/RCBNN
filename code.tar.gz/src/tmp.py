# -*- coding: utf-8 -*-
# @Time    : 2021/10/16 8:17 下午
# @Author  : Yushuo Wang
# @FileName: tmp.py
# @Software: PyCharm
# @Blog    ：https://lesliewongcv.github.io/
import numpy as np
C = [_ for _ in range(-5,16)]

y = [1/2**__ for __ in C]

_=1