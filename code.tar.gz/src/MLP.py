# -*- coding: utf-8 -*-
# @Time    : 2021/9/17 7:49 下午
# @Author  : Yushuo Wang
# @FileName: SVM.py
# @Software: PyCharm
# @Blog    ：https://lesliewongcv.github.io/


from scipy.io import loadmat
from sklearn.model_selection import KFold
import torch
import torch.nn as nn
from torchsummary import summary
import numpy as np
import matplotlib.pyplot as plt
PATH = 'Data/'
df_train = torch.from_numpy(loadmat(PATH + 'data_train.mat')['data_train']).float()
df_test = torch.from_numpy(loadmat(PATH + 'data_test.mat')['data_test']).float()
df_label = torch.from_numpy(loadmat(PATH + 'label_train.mat')['label_train'].squeeze()).float()
K =4
kf = KFold(n_splits=K, shuffle=False)
kf.split(df_label)
vali_res = 0


class Net(nn.Module):
    def __init__(self,n_input,n_hidden,n_output):
        super(Net,self).__init__()
        self.hidden1 = nn.Linear(n_input,n_hidden)
        self.hidden2 = nn.Linear(n_hidden,n_hidden)
        self.predict = nn.Linear(n_hidden,n_output)
        self.dropout = nn.Dropout()
        self.bn = nn.BatchNorm1d(n_hidden)
        self.threshold = 0
    def forward(self,input):
        out = self.hidden1(input)
        out = torch.relu(out)
        out = self.dropout(out)
        # out = self.bn(out) BAD
        out = self.hidden2(out)
        # out = self.bn(out) GOOD
        out = torch.sigmoid(out)
        out =self.predict(out)

        return out

    def getThreshold(self, output, label, training=True):
        acc = 0
        threshold = 0
        th_list = np.arange(-0.5, 0.7, 0.05)
        ACC = []
        for i in th_list:
            acc_ = self.acc(output, i, label)
            ACC.append(acc_)
            # print('threshold=%.2f' % i + ' | acc = %.5f' % acc_)
            if acc_ > acc:
                acc = acc_
                threshold = i
        # print('*' * 20 + '\n')
        # print('Choosing %0.2f as threshold' % threshold + 'acc = %.5f' % acc + '\n')
        # print('*' * 20 + '\n')
        self.threshold = threshold
        if not training:
            plt.plot(th_list, ACC, c='orange')
            plt.ylabel('ACC')
            plt.xlabel('Threshold')
            plt.title('Acc with different thresholds on Validation set')
            plt.show()
        return acc
    def acc(self, output, threshold, label, training=True):
        res = np.ones(output.shape)
        res[output > threshold] = 1
        res[output < threshold] = -1
        if training:
            return sum(np.squeeze(res) == label.detach().numpy()) / output.size()[0]
        else:
            return res

N = np.arange(10, 500, 10)
N = [100]
TEST =[]
ACC_V = []
for n in N:
    net = Net(33,n,1)
    optimizer = torch.optim.SGD(net.parameters(),lr = 0.03)
    # optimizer = torch.optim.Adam(net.parameters(),lr = 0.03)
    loss_func = torch.nn.MSELoss()

    # train_index, valid_index = next(kf.split(df_label))

    train_acc = 0
    valid_acc = 0

    train_index, valid_index = next(kf.split(df_label))  # 4-fold
    # summary(net, (330, 33))
    print('\n')
    print("N =  %d" % n, end="")
    print('\n')
    for i in range(10000):
        # train_x = df_train[train_index][torch.randperm(df_train[train_index].size()[0])][:16]
        # res_train = net(train_x).squeeze()
        # res_train = net(df_train[train_index]).squeeze()
        # loss = loss_func(res_train, df_label[train_index])
        res_train = net(df_train[train_index]).squeeze()
        loss = loss_func(res_train, df_label[train_index])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        print('\b'*len(str(i)) + str(i), end='', flush=True)

        if i % 1000 == 0:
            # res_train = torch.sign(res_train)
            # train_acc = sum(res_train == df_label[train_index]) / len(train_index)
            # train_acc = sum(res_train == df_label) / len(train_index)

            # res_valid = torch.sign(net(df_train[valid_index]).squeeze())
            # valid_acc = sum(res_valid == df_label[valid_index]) / len(valid_index)
            # loss_v = loss_func(res_valid, df_label[valid_index])
            # print('Training:')
            acc_t = net.getThreshold(res_train, df_label[train_index])
            # print('Validation:')
            res_valid = net(df_train[valid_index]).squeeze()
            acc_v = net.getThreshold(res_valid, df_label[valid_index])
            if acc_v > valid_acc:
                valid_acc = acc_v

            # print('i-'+ str(i) + ' Train acc: ' + str(train_acc.numpy()) + ' loss：' + str(loss.item()) + ' | ' + 'Valid acc : ' + str(
            #     valid_acc.numpy()) + ' loss：' + str(loss_v.item()))
    print()
    print('acc = %.5f' % valid_acc)
    res_test = net.acc(net(df_test).squeeze(), net.threshold, None, False).reshape((21,1))
    TEST.append(res_test)
    ACC_V.append(valid_acc)
_ = 1

'10000 BatchGD Train acc: 0.99636364 | Valid acc : 0.8545455 loss：tensor(0.0330, grad_fn=<MseLossBackward>)'
'100000 BatchGD Train acc: 1.0 | Valid acc : 0.92727274 loss：tensor(0.0113, grad_fn=<MseLossBackward>)'
# print('Train acc: ' + str(train_acc.numpy() / K*10) + ' | ' + 'Valid acc : ' + str(valid_acc.numpy() / K*10) + ' loss：' + str(loss))
#
# for train_index, valid_index in kf.split(df_label):  # 4-fold
#     net = Net(33, 100, 1)
#     optimizer = torch.optim.SGD(net.parameters(), lr=0.03)
#     loss_func = torch.nn.MSELoss()
#
#     for i in range(10000):
#         res_train = net(df_train[train_index]).squeeze()
#         loss = loss_func(res_train, df_label[train_index])
#         optimizer.zero_grad()
#         loss.backward()
#         optimizer.step()
#         if i % 1000 == 0:
#             res_train = torch.sign(res_train)
#             train_acc += sum(res_train == df_label[train_index]) / len(train_index)
#
#             res_valid = torch.sign(net(df_train[valid_index]).squeeze())
#             valid_acc += sum(res_valid == df_label[valid_index]) / len(valid_index)
#             print('loss:' + str(loss))
# print('Train acc: ' + str(train_acc.numpy() / K * 10) + ' | ' + 'Valid acc : ' + str(
#     valid_acc.numpy() / K * 10) + ' loss：' + str(loss))
#
'Train acc: 95.04851023356119 | Valid acc : 88.99999618530273 loss：tensor(0.0308, grad_fn=<MseLossBackward>)'
import pandas as pd
df_pds = pd.DataFrame(df_train.detach().numpy())
df_label_pd = pd.DataFrame(df_label.detach().numpy())
df_label_pd.columns = [33]
# df = pd.concat([df_pds, df_label_pd],axis=1)
# plt.figure(figsize=(16,10), dpi= 80)
# fig, axes = joypy.joyplot(df, column= [_ for _ in range(33)], by=33,figsize=(14,10))
# plt.title('Distributions of 33 dimensions by Class -1 and 1', fontsize=32)
# plt.show()


plt.plot(N, ACC_V, c='green')
plt.ylabel('ACC')
plt.xlabel('No. of Neurons')
plt.title('Acc with different No. of neurons on Validation set')
plt.show()