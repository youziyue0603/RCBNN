# -*- coding: utf-8 -*-
# @Time    : 2023/3/23 0:52
# @Author  : Yushuo Wang
# @FileName: molecular.py
# @Software: PyCharm
# @Blog    ：https://lesliewongcv.github.io/
import os, sys
import numpy as np
import torch
from torchvision import datasets, transforms
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
import torch.nn as nn

########################################################################################################################

def get(data_path, seed=0, fixed_order=False, pc_valid=0):
    data = {}
    taskcla = []
    size = [1, 28, 28]
    path = os.path.join(data_path, 'molecular_shape')
    path = r'/content/drive/MyDrive/researchHub/UCB_correct/data/molecular_shape'

    data_load = np.load(os.path.join(path, 'molecular_shape.npy'))
    data_load = torch.from_numpy(data_load).squeeze()
    data_load_reshape= torch.reshape(data_load, (20000, 1, 200, 200))[:, :, 50:150, 50:150]
    up_sampling = nn.Upsample(size=[28, 28])
    data_load_reshape = up_sampling(data_load_reshape).to(torch.float32)
    data_load_idx = 0

    for i in range(5):
        data[i] = {}
        data[i]['name'] = 'molecular_shape-0-1'
        data[i]['ncla'] = 2

        data_load_task_i_x = data_load_reshape[2000*data_load_idx:2000*(data_load_idx+2)]
        data_load_task_i_y = torch.zeros([4000], dtype=torch.int64)
        data_load_task_i_y[2000:] = 1
        X_train, X_test, y_train, y_test = train_test_split(data_load_task_i_x, data_load_task_i_y,
                                                            test_size=0.2, random_state = 42)
        data[i]['train'] = {'x': [], 'y': []}
        data[i]['test'] = {'x': [], 'y': []}

        data[i]['train']['x'] = X_train
        data[i]['train']['y'] = y_train
        data[i]['test']['x'] = X_test
        data[i]['test']['y'] = y_test

    # Validation
    for t in data.keys():
        data[t]['valid'] = {}
        data[t]['valid']['x'] = data[t]['train']['x'].clone()
        data[t]['valid']['y'] = data[t]['train']['y'].clone()

    n=0
    for t in data.keys():
        taskcla.append((t,data[t]['ncla']))
        n+=data[t]['ncla']
    data['ncla']=n

    return data, taskcla, size

########################################################################################################################


