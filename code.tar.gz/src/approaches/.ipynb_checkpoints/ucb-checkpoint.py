import sys, time
import numpy as np
import torch
import torch.nn.functional as F
from copy import deepcopy
import torch.nn as nn
import math


class Appr(object):
    def __init__(self, model, args):
        self.model = model
        self.args = args
        self.device = args.device
        self.criterion = torch.nn.CrossEntropyLoss()
        self.optimizer = self._get_optimizer()
        
        self.samples = args.samples
        self.rho = args.rho
        self.sig1 = args.sig1
        self.sig2 = args.sig2
        self.pi = args.pi
        
    def _get_optimizer(self):
        if self.args.optimizer == 'SGD':
            return torch.optim.SGD(self.model.parameters(), lr=self.args.lr)
        elif self.args.optimizer == 'ADAM':
            return torch.optim.Adam(self.model.parameters(), lr=self.args.lr)
        else:
            raise NotImplementedError

    # 在 ucb.py 中，将 train 方法替换为：
    def train(self, task_t, task_v, xtrain, ytrain, xvalid, yvalid, loss_list):
        """最简化的训练版本，专注于NLL损失"""
        self.model.train()

        Loss1Tsk = torch.zeros((4, self.args.nepochs))
        Loss1Tsk_T = torch.zeros((2, self.args.nepochs))

        for epoch in range(self.args.nepochs):
            self.model.train()
            total_loss = 0

            r = np.arange(xtrain.size(0))
            np.random.shuffle(r)
            r = torch.LongTensor(r).to(self.device)

            for i in range(0, len(r), self.args.sbatch):
                if i + self.args.sbatch <= len(r):
                    b = r[i:i + self.args.sbatch]
                else:
                    b = r[i:]

                images = xtrain[b]
                targets = ytrain[b]
                task_batch = task_t[b]

                self.optimizer.zero_grad()

                # 只使用NLL损失，暂时忽略KL正则化
                outputs = self.model(images, sample=True)

                nll_loss = 0
                for t in range(self.args.tasks):
                    task_mask = (task_batch == t)
                    if task_mask.sum() > 0:
                        task_outputs = outputs[t][task_mask]
                        task_targets = targets[task_mask]
                        nll_loss += F.nll_loss(task_outputs, task_targets, reduction='sum')

                loss = nll_loss / len(b)

                if not (torch.isnan(loss) or torch.isinf(loss)):
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                    self.optimizer.step()
                    total_loss += loss.item()

            if epoch % 10 == 0 or epoch == self.args.nepochs - 1:
                print(f'Epoch {epoch:3d}, Train Loss: {total_loss:8.4f}')

            Loss1Tsk[0, epoch] = total_loss
            Loss1Tsk[1, epoch] = 0
            Loss1Tsk[2, epoch] = total_loss
            Loss1Tsk[3, epoch] = total_loss

            Loss1Tsk_T[0, epoch] = total_loss
            Loss1Tsk_T[1, epoch] = 0

        return Loss1Tsk, Loss1Tsk_T

    def eval(self, task, x, y, debug=False):
        self.model.eval()
        total_loss = 0
        total_acc = 0
        total_num = 0
        fail_indices = []
        
        with torch.no_grad():
            r = np.arange(x.size(0))
            r = torch.LongTensor(r).to(self.device)
            
            for i in range(0, len(r), self.args.sbatch):
                if i + self.args.sbatch <= len(r):
                    b = r[i:i + self.args.sbatch]
                else:
                    b = r[i:]
                
                images = x[b]
                targets = y[b]
                task_batch = task[b] if task.dim() > 0 else task
                
                # Forward pass (using mean of distributions)
                outputs = self.model(images, sample=False)
                
                # Calculate loss and accuracy
                for t in range(self.args.tasks):
                    if isinstance(task_batch, torch.Tensor):
                        task_mask = (task_batch == t)
                    else:
                        task_mask = (task_batch == t) if task_batch == t else torch.zeros_like(targets, dtype=torch.bool)
                    
                    if task_mask.sum() > 0:
                        task_outputs = outputs[t][task_mask]
                        task_targets = targets[task_mask]
                        
                        loss = F.nll_loss(task_outputs, task_targets)
                        pred = task_outputs.argmax(dim=1)
                        acc = (pred == task_targets).float()
                        
                        total_loss += loss.item() * task_mask.sum().item()
                        total_acc += acc.sum().item()
                        total_num += task_mask.sum().item()
                        
                        if debug:
                            # Record failed predictions
                            failed = (pred != task_targets)
                            if failed.sum() > 0:
                                fail_indices.extend(b[task_mask][failed].cpu().tolist())
        
        avg_loss = total_loss / total_num if total_num > 0 else 0
        avg_acc = total_acc / total_num if total_num > 0 else 0
        
        if debug:
            return avg_loss, avg_acc, fail_indices, None
        else:
            return avg_loss, avg_acc

    def eval_var(self, task, x, y):
        """Evaluate uncertainty using Monte Carlo sampling for RCB rehearsal selection"""
        self.model.eval()
        
        all_predictions = []
        fail_indices = []
        
        with torch.no_grad():
            # Multiple forward passes for uncertainty estimation
            for _ in range(self.samples):
                task_predictions = []
                outputs = self.model(x, sample=True)
                
                for t in range(self.args.tasks):
                    if isinstance(task, torch.Tensor):
                        task_mask = (task == t)
                    else:
                        task_mask = (task == t) if task == t else torch.zeros(x.size(0), dtype=torch.bool).to(self.device)
                    
                    if task_mask.sum() > 0:
                        task_outputs = outputs[t][task_mask]
                        # Convert log probabilities to probabilities
                        probs = torch.exp(task_outputs)
                        task_predictions.append(probs)
                    else:
                        task_predictions.append(torch.empty(0, self.args.taskcla[0][1]).to(self.device))
                
                all_predictions.append(task_predictions)
            
            # Calculate variance across samples
            uncertainties = []
            for i in range(len(x)):
                # Find which task this sample belongs to
                if isinstance(task, torch.Tensor):
                    sample_task = task[i].item()
                else:
                    sample_task = task
                
                # Collect predictions for this sample across all MC samples
                sample_preds = []
                sample_idx_in_task = 0
                
                # Find the index of this sample within its task
                if isinstance(task, torch.Tensor):
                    task_mask = (task == sample_task)
                    sample_idx_in_task = (task[:i+1] == sample_task).sum().item() - 1
                else:
                    sample_idx_in_task = i
                
                for sample_num in range(self.samples):
                    if len(all_predictions[sample_num][sample_task]) > sample_idx_in_task:
                        pred = all_predictions[sample_num][sample_task][sample_idx_in_task]
                        sample_preds.append(pred)
                
                if sample_preds:
                    # Calculate variance across MC samples
                    sample_preds = torch.stack(sample_preds)
                    variance = torch.var(sample_preds, dim=0).mean().item()
                    uncertainties.append(variance)
                else:
                    uncertainties.append(0.0)
            
            # Check for failed predictions (using mean prediction)
            mean_outputs = self.model(x, sample=False)
            for i in range(len(x)):
                if isinstance(task, torch.Tensor):
                    sample_task = task[i].item()
                    sample_idx_in_task = (task[:i+1] == sample_task).sum().item() - 1
                else:
                    sample_task = task
                    sample_idx_in_task = i
                
                if isinstance(task, torch.Tensor):
                    task_mask = (task == sample_task)
                    if task_mask.sum() > sample_idx_in_task:
                        pred = mean_outputs[sample_task][task_mask][sample_idx_in_task].argmax()
                        true_label = y[i]
                        if pred != true_label:
                            fail_indices.append(i)
                else:
                    if i < len(mean_outputs[sample_task]):
                        pred = mean_outputs[sample_task][i].argmax()
                        true_label = y[i]
                        if pred != true_label:
                            fail_indices.append(i)
        
        return torch.tensor(uncertainties).to(self.device), fail_indices

    def check_embedding(self, task, x, y, weights_last, debug=False):
        """Check feature embedding for analysis"""
        self.model.eval()
        with torch.no_grad():
            z = self.model(x, z_flag=True)
            return z.mean().item()