import os, sys, time
import numpy as np
import copy
import math
import torch
import torch.nn.functional as F
from .utils import BayesianSGD
import matplotlib.pyplot as plt
#import pdb

class Appr(object):

    def __init__(self, model, args, lr_min=1e-6, lr_factor=3, lr_patience=5, clipgrad=1000):
        self.model = model
        self.device = args.device
        self.lr_min = lr_min
        self.lr_factor = lr_factor
        self.lr_patience = lr_patience
        self.clipgrad = clipgrad

        self.init_lr = args.lr
        self.sbatch = args.sbatch
        self.nepochs = args.nepochs

        self.arch = args.arch
        self.samples = args.samples
        self.lambda_ = 1.

        self.output = args.output
        self.checkpoint = args.checkpoint
        self.experiment = args.experiment
        self.num_tasks = args.num_tasks

        self.modules_names_with_cls = self.find_modules_names(with_classifier=True)
        self.modules_names_without_cls = self.find_modules_names(with_classifier=False)
        
    def get_var(self, t_all, xtrain, ytrain, xvalid, yvalid, weights_last, loss_list):

        pred_var = self.model(xtrain, weights_last, True, sample=False)[1][t_all[0]]  # 2mlp

        return pred_var

    def train(self, t_t, t_v, xtrain, ytrain, xvalid, yvalid, weights_last, loss_list):
        clock00 = time.time()
        cls_t = int(torch.mode(t_t).values)
        cls_v = int(torch.mode(t_v).values)
        # Update the next learning rate for each parameter based on their uncertainty
        params_dict = self.update_lr(t_t[0], adaptive_lr = True, lr = self.init_lr)
        self.optimizer = BayesianSGD(params=params_dict)
        # self.loss_list = l
        best_loss = np.inf

        # best_model=copy.deepcopy(self.model)
        best_model = copy.deepcopy(self.model.state_dict())
        lr = self.init_lr
        patience = self.lr_patience
        # weights_last = torch.tensor([0, 1, 1, 1])  # how to init
        # Loop epochs
        clock000 = time.time()
        # print('pre-training: time=' + str(clock000 - clock00))

        try:
            for e in range(self.nepochs):
                # Train
                clock0 = time.time()
                self.train_epoch(t_t, xtrain, ytrain, weights_last, loss_list)
                clock1 = time.time()
                # print('train_epoch : time=' + str(clock1 - clock0))

                train_loss, train_acc = self.eval(t_t, xtrain, ytrain, weights_last)
                clock2 = time.time()
                # print('eval : time=' + str(clock2 - clock1))

                print('| Epoch {:3d}, time={:5.1f}ms/{:5.1f}ms | Train: loss={:.3f}, acc={:5.1f}% |'.format(e + 1,
                                    1000 * self.sbatch * (
                                                clock1 - clock0) / xtrain.size(
                                        0),
                                    1000 * self.sbatch * (
                                                clock2 - clock1) / xtrain.size(
                                        0),
                                    1e5 * train_loss,
                                    100 * train_acc),
                      end='')
                # Valid

                valid_loss, valid_acc = self.eval(t_v, xvalid, yvalid, weights_last)
                print(' Valid: loss={:.3f}, acc={:5.1f}% |'.format(1e5*valid_loss, 100 * valid_acc), end='')

                if math.isnan(valid_loss) or math.isnan(train_loss):
                    print("saved best model and quit because loss became nan")
                    break
                clock3 = time.time()
                # print('Valid: time=' + str(clock3 - clock2))

                # Adapt lr
                if valid_loss < best_loss:
                    best_loss = valid_loss
                    best_model = copy.deepcopy(self.model.state_dict())
                    patience = self.lr_patience
                    print(' *', end='')
                else:
                    patience -= 1
                    if patience <= 0:
                        lr /= self.lr_factor
                        print(' lr={:.1e}'.format(lr), end='')
                        if lr < self.lr_min:
                            print()
                            break
                        patience = self.lr_patience

                        params_dict = self.update_lr(cls_t, adaptive_lr=True, lr=lr)  # True
                        self.optimizer = BayesianSGD(params=params_dict)
                clock4 = time.time()
                print()
                # print('Adapt lr: time=' + str(clock4 - clock3))
                # print('One epoch: time=' + str(clock4 - clock0))
        except KeyboardInterrupt:
            print()

        # Restore best
        self.model.load_state_dict(copy.deepcopy(best_model))
        self.save_model(cls_t)

    def update_lr(self, t, lr=None, adaptive_lr=False):
        params_dict = []
        if t == 0:
            params_dict.append({'params': self.model.parameters(), 'lr': self.init_lr})
        else:
            for name in self.modules_names_without_cls:
                n = name.split('.')
                if len(n) == 1:
                    m = self.model._modules[n[0]]
                elif len(n) == 3:
                    m = self.model._modules[n[0]]._modules[n[1]]._modules[n[2]]
                elif len(n) == 4:
                    m = self.model._modules[n[0]]._modules[n[1]]._modules[n[2]]._modules[n[3]]
                else:
                    print(name)

                if adaptive_lr is True:
                    params_dict.append({'params': m.weight_mu, 'lr': lr})
                    params_dict.append({'params': m.bias_mu, 'lr': lr})
                    params_dict.append({'params': m.weight_rho, 'lr': lr}) # add-on
                    params_dict.append({'params': m.bias_rho, 'lr': lr})  # add-on



                else:
                    print("UCB" * 10)
                    w_unc = torch.log1p(torch.exp(m.weight_rho.data))
                    b_unc = torch.log1p(torch.exp(m.bias_rho.data))

                    params_dict.append({'params': m.weight_mu, 'lr': torch.mul(w_unc, self.init_lr)})
                    params_dict.append({'params': m.bias_mu, 'lr': torch.mul(b_unc, self.init_lr)})
                    params_dict.append({'params': m.weight_rho, 'lr': self.init_lr})
                    params_dict.append({'params': m.bias_rho, 'lr': self.init_lr})


        return params_dict

    def find_modules_names(self, with_classifier=False):
        modules_names = []
        for name, p in self.model.named_parameters():
            if with_classifier is False:
                if not name.startswith('classifier'):
                    n = name.split('.')[:-1]
                    modules_names.append('.'.join(n))
            else:
                n = name.split('.')[:-1]
                modules_names.append('.'.join(n))

        modules_names = set(modules_names)

        return modules_names

    def logs(self, t):
        #cls_n = int(torch.mode(t).values)
        lp, lvp = 0.0, 0.0
        for name in self.modules_names_without_cls:
            n = name.split('.')
            if len(n) == 1:
                m = self.model._modules[n[0]]
            elif len(n) == 3:
                m = self.model._modules[n[0]]._modules[n[1]]._modules[n[2]]
            elif len(n) == 4:
                m = self.model._modules[n[0]]._modules[n[1]]._modules[n[2]]._modules[n[3]]

            lp += m.log_prior  # fc's loss
            lvp += m.log_variational_posterior
        # print('prior loss_fc:' + lp.detach().cpu().numpy())
        lp += self.model.classifier[t].log_prior # classifier loss
        # print('prior loss_fc+cls:' + lp.detach().cpu().numpy())
        lvp += self.model.classifier[t].log_variational_posterior

        return lp, lvp

    def train_epoch(self, t, x, y, weights_last, loss_list):
        clock0 = time.time()
        self.model.train()
        clock1 = time.time()
        # print('train: time=' + str(clock1 - clock0))
        t_unq = torch.sort(torch.unique(t), descending=True).values
        offset = 0
        for idx in t_unq:
            t_ = t[t == idx]
            r = np.arange(t_.size(0)) + offset
            offset += len(t_)
            # np.random.shuffle(r)  # index shouldn't be shuffered
            r = torch.LongTensor(r).to(self.device)
            num_batches = len(r) // self.sbatch
            for i in range(0, len(r), self.sbatch):  # sbatch 总：30596  64个

                clock2=time.time()
                if i + self.sbatch <= len(r):
                    b = r[i:i + self.sbatch]
                else:
                    b = r[i:]
                images, targets, t_sub = x[b].to(self.device), y[b].to(self.device), t[b].to(self.device)
                # Forward
                cls_n = int(torch.mode(t_sub).values)
                loss, weights_last = self.elbo_loss(images, targets, cls_n, num_batches, weights_last, loss_list,  sample_=True, i_ = i/self.sbatch)#.to(self.device)
                clock3=time.time()
                # print('loop: time=' + str(clock3 - clock2))
                # out_packed = self.elbo_loss(images, targets, t, num_batches, weights_last, sample=True).to(self.device)
                # loss = out_packed[0]
                # weights_last = out_packed[1]

                # Backward
                self.model.cuda()
                self.optimizer.zero_grad()
                loss.backward(retain_graph=True)  # 两个classifiers 反向传播更新几个？
                self.model.cuda()

                # Update parameters ms/
                self.optimizer.step()  # 不注释
                clock4=time.time()
            # print('bp: time=' + str(clock4 - clock3))
            #tmp.mean()
            #tensor(-7.1972e-05, grad_fn=<MeanBackward0>)
        # clock2 = time.time()
        # print('loop: time=' + str(clock2 - clock1))

        return

    def eval(self, t, x, y, weights_last, debug=False):
        total_loss = 0
        total_acc = 0
        total_num = 0
        self.model.eval()
        loss_list = []

        with torch.no_grad():
            t_unq = torch.sort(torch.unique(t), descending=True).values
            offset = 0
            for idx in t_unq:
                t_ = t[t == idx]
                r = np.arange(t_.size(0)) + offset
                offset += len(t_)
                r = torch.LongTensor(r).to(self.device)
                num_batches = len(r) // self.sbatch
                for i in range(0, len(r), self.sbatch):  # sbatch 总：30596  64个

                    if i + self.sbatch <= len(r):
                        b = r[i:i + self.sbatch]
                    else:
                        b = r[i:]
                    images, targets = x[b].to(self.device), y[b].to(self.device)
                    # Forward
                    outputs = self.model(images, weights_last, sample=False)
                    cls_n = int(torch.mode(t).values)
                    output = outputs[cls_n]
                    loss = self.elbo_loss(images, targets, cls_n, num_batches, weights_last, loss_list, sample_=False, debug=debug)
                    _, pred = output.max(1, keepdim=True)
                    total_loss += loss.detach() * len(b)
                    total_acc += pred.eq(targets.view_as(pred)).sum().item()
                    total_num += len(b)
        return total_loss / total_num, total_acc / total_num

    def check_embedding(self, t, x, y, weights_last, debug=False):
        total_loss = 0
        total_acc = 0
        total_num = 0
        self.model.eval()
        loss_list = []
        r = np.arange(x.size(0))
        r = torch.as_tensor(r, device=self.device, dtype=torch.int64)

        with torch.no_grad():

            num_batches = len(x) // self.sbatch
            # Loop batches
            for i in range(0, len(r), self.sbatch):
                if i + self.sbatch <= len(r):
                    b = r[i:i + self.sbatch]
                else:
                    b = r[i:]
                images, targets = x[b].to(self.device), y[b].to(self.device)

                # Forward
                outputs = self.model(images, weights_last, sample=False, z_flag = True)
                x_ = outputs[t][:, 0].detach().cpu().numpy()
                y_ = outputs[t][:, 1].detach().cpu().numpy()
                # print(i)
                # print(len(r))
                if i == 0:  # 4992 for check the mnist2

                  mask_0 = (targets == 0).nonzero(as_tuple=True)[0].detach().cpu().numpy()
                  mask_1 = (targets == 1).nonzero(as_tuple=True)[0].detach().cpu().numpy()
                  mask_2 = (targets == 2).nonzero(as_tuple=True)[0].detach().cpu().numpy()
                  mask_3 = (targets == 3).nonzero(as_tuple=True)[0].detach().cpu().numpy()
                  mask_4 = (targets == 4).nonzero(as_tuple=True)[0].detach().cpu().numpy()

                  x_0 = x_[mask_0]; y_0 = y_[mask_0]; x_1 = x_[mask_1]; y_1 = y_[mask_1]
                  x_2 = x_[mask_2]; y_2 = y_[mask_2]; x_3 = x_[mask_3]; y_3 = y_[mask_3]
                  x_4 = x_[mask_4]; y_4 = y_[mask_4];


                  plt.scatter(x_0,y_0, c='r'); plt.scatter(x_0, y_0, c ='b')
                  plt.scatter(x_1,y_1, c='g'); plt.scatter(x_2, y_2, c ='orange')
                  plt.scatter(x_3,y_3, c='r'); plt.scatter(x_4, y_4, c ='yellow')
                  plt.title('latent space(fc1)')
                  plt.savefig('plt %d.jpg'%(t+1))
                  plt.show()
                  # import pdb; pdb.set_trace()
                else:
                  pass
                # output = outputs[t]
                # loss = self.elbo_loss(images, targets, t, num_batches, weights_last, loss_list, sample=False,
                #                       debug=debug)

                # _, pred = output.max(1, keepdim=True)

                # total_loss += loss.detach() * len(b)
                # total_acc += pred.eq(targets.view_as(pred)).sum().item()
                # total_num += len(b)

        return outputs[t]

    def set_model_(model, state_dict):
        model.model.load_state_dict(copy.deepcopy(state_dict))

    def elbo_loss(self, input, target, t, num_batches, weights_last,loss_list, sample_, debug=False, i_= 1):
        if sample_:
            lps, lvps, predictions, fc1_mu_last, fc1_rho_last, cls_mu_last, cls_rho_last = [], [], [], [], [], [], []
            for i in range(self.samples):  # 利用prediction sample10次 每次weights会更新?
                #import pdb; pdb.set_trace()
                predictions.append(self.model(input, weights_last, sample=sample_)[t])  # input 过网络输出两个预测（两个classifier）
                # input.size()                                           # 只取一个[t]
                # torch.Size([64, 1, 28, 28])
                lp, lv = self.logs(t) # here
                lps.append(lp)
                lvps.append(lv)

                # fc1_mu_last.append(self.model.fc1.weight_mu.mean())
                # fc1_rho_last.append(self.model.fc1.weight_rho.mean())
                # cls_mu_last.append(self.model.classifier[t].weight_mu.mean())
                # cls_rho_last.append(self.model.classifier[t].weight_rho.mean())
            # hack
            w1 = 1.e-1  #balance this  -3
            w2 = 1.e-1
            w3 = 5.e-2

            w1 = 0.2**(num_batches - i_) / (2**num_batches - 1)
            w2 = w1
            w3 = 0.1
            # print('w1:')
            # print(w1)

            # weights_last = torch.tensor([torch.as_tensor(fc1_mu_last, device=self.device).mean(), torch.as_tensor(fc1_rho_last, device=self.device).mean(),
            #                 torch.as_tensor(cls_mu_last, device=self.device).mean(), torch.as_tensor(cls_rho_last, device=self.device).mean()])

            fc1_mu_last = self.model.fc1.weight_mu
            fc1_rho_last = self.model.fc1.weight_rho  # metrics
            cls_mu_last = self.model.classifier[t].weight_mu
            cls_rho_last = self.model.classifier[t].weight_rho
            weights_last = [fc1_mu_last, fc1_rho_last, cls_mu_last, cls_rho_last]
            #pdb.set_trace()
            outputs = torch.stack(predictions, dim=0).to(self.device)
            log_var = w1 * torch.as_tensor(lvps, device=self.device).mean()
            log_p = w2 * torch.as_tensor(lps, device=self.device).mean()
            nll = w3 * torch.nn.functional.nll_loss(outputs.mean(0), target, reduction='sum').to(device=self.device)
            # if math.isinf(nll) or torch.any(torch.isnan(nll)):
            #   print('nll is exceeded')
            # if math.isinf(log_p) or torch.any(torch.isnan(log_p)):
            #   print('log_p is exceeded')
            # if math.isinf(log_var) or torch.any(torch.isnan(log_var)):
            #   print('logvar is exceeded')
        # if sample: # already sample
            # loss_list.append((log_var/w1).cpu().detach().numpy())
            # loss_list.append((log_p/w2).cpu().detach().numpy())
            # loss_list.append((nll/w3).cpu().detach().numpy())
        #     w1, w2, w3 = self.get_coefs(nll,log_var,log_p,num_batches)
        #     print ("New coefficients for task {} are w1={}, w2={}, w3={}".format(t,w1,w2,w3))
        #     import pdb; pdb.set_trace()
        #     if math.isnan(log_var) or math.isnan(log_p) or math.isnan(nll):
        #         nll = torch.nn.functional.nll_loss(outputs.mean(0), target, reduction='sum')
        # # if log_var > 1e3 or log_p > 1e3 or nll>1e3:
        #     print ("BEFORE: ", (log_var/num_batches).item(), (log_p / num_batches).item(), nll.item())
        #     # while math.isnan(nll):
        #         # nll = 1e-5*torch.nn.functional.nll_loss(outputs.mean(0), target, reduction='sum')

            return (log_var - log_p) / num_batches + nll, weights_last
            # return nll, weights_last  # only on nll

        else:
            predictions = []
            for i in range(self.samples):
                pred = self.model(input, weights_last, sample=False)[t]
                predictions.append(pred)

            # hack
            # w1 = 1.e-3
            # w2 = 1.e-3
            w3 = 5.e-6

            outputs = torch.stack(predictions, dim=0).to(self.device)
            nll = w3 * torch.nn.functional.nll_loss(outputs.mean(0), target, reduction='sum').to(device=self.device)

            return nll

        # w1, w2, w3 = self.get_coefs(nll,log_var,log_p,num_batches)
        # print ("New coefficients for task {} are w1={}, w2={}, w3={}".format(t,w1,w2,w3))
        # # import pdb; pdb.set_trace()
        # if math.isnan(log_var) or math.isnan(log_p) or math.isnan(nll):
        #     nll = torch.nn.functional.nll_loss(outputs.mean(0), target, reduction='sum')
        # # if log_var > 1e3 or log_p > 1e3 or nll>1e3:
        #     print ("BEFORE: ", (log_var/num_batches).item(), (log_p / num_batches).item(), nll.item())
        #     # while math.isnan(nll):
        #         # nll = 1e-5*torch.nn.functional.nll_loss(outputs.mean(0), target, reduction='sum')

    def save_model(self, t):
        torch.save({'model_state_dict': self.model.state_dict(),
                    }, os.path.join(self.checkpoint, 'model_{}.pth.tar'.format(t)))

    # def get_coefs(self,nll,log_var,log_p,num_batches):
    #     def take_n(num):
    #         return torch.log10(num).item()
    #     import pdb; pdb.set_trace()
    #     exponents = np.array([take_n(num) for num in [nll, log_p, log_var]])
    #     min_exp = exponents.min()
    #     min_exp_idx = np.argmin(exponents)
    #     if min_exp_idx == 0:
    #         w1 = (10**(3-(take_n(log_var)+min_exp)))*num_batches
    #         w2 = (10**-(3-(take_n(log_p)+min_exp)))*num_batches
    #         w3 = 10.**(3-min_exp_idx)
    #     if min_exp_idx == 1:
    #         w1 = (10**(3-(take_n(log_var)+min_exp)))*num_batches
    #         w3 = 10**(3-(take_n(nll)+min_exp))
    #         w2 = (10.**-(3-min_exp_idx))*num_batches
    #     if min_exp_idx == 2:
    #         w3 = 10**(3-(take_n(nll)+min_exp))
    #         w2 = (10**-(3-(take_n(log_p)+min_exp)))*num_batches
    #         w1 = (10.**(3-min_exp_idx))*num_batches
    
    #     return w1, w2, w3
