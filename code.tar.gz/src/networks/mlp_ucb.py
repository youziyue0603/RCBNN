import torch
import numpy as np
from .FC import BayesianLinear


class BayesianMLP(torch.nn.Module):
    """
    Bayesian Multi-Layer Perceptron for RCB (Rehearsal-based Continual Bayes)
    """

    def __init__(self, args):
        super(BayesianMLP, self).__init__()

        ncha, size, _ = args.inputsize
        self.taskcla = args.taskcla
        self.samples = args.samples
        self.device = args.device
        self.sbatch = args.sbatch
        self.init_lr = args.lr
        self.print_val = args.print_val
        self.ncls = args.ncls
        self.tasks = args.tasks

        # Network architecture
        dim = args.nhid
        nlayers = args.nlayers

        # First hidden layer
        self.fc1 = BayesianLinear(ncha * size * size, dim, args)

        # Optional second hidden layer
        if nlayers == 2:
            self.fc2 = BayesianLinear(dim, dim, args)

        # Task-specific classifiers
        self.classifier = torch.nn.ModuleList()
        for t, n in self.taskcla:
            self.classifier.append(BayesianLinear(dim, n, args))

    def prune(self, mask_modules):
        """RCB pruning support"""
        for module, mask in mask_modules.items():
            module.prune_module(mask)

    def forward(self, x, print_var=False, sample=False, z_flag=False):
        """
        Forward pass for RCB
        Args:
            x: Input tensor [batch, channels, height, width]
            print_var: Return variance information for uncertainty estimation
            sample: Sample from posterior distributions
            z_flag: Return intermediate features
        """
        # Flatten input
        x = x.view(x.size(0), -1)

        # Initialize output tensors for multiple tasks
        res = torch.zeros([self.tasks, x.size()[0], self.taskcla[0][-1]]).to(self.device)
        res_double = torch.zeros([2, self.tasks, x.size()[0], self.taskcla[0][-1]]).to(self.device)

        # First hidden layer
        x = self.fc1(x, print_var=False, sample=sample)
        if isinstance(x, list) and len(x) == 2:
            x = torch.nn.functional.relu(x[0])
        else:
            x = torch.nn.functional.relu(x)

        # Optional second hidden layer
        if hasattr(self, 'fc2'):
            x = self.fc2(x, print_var=False, sample=sample)
            if isinstance(x, list) and len(x) == 2:
                x = torch.nn.functional.relu(x[0])
            else:
                x = torch.nn.functional.relu(x)

        # Store intermediate features if requested
        z = x.clone()

        # Task-specific classification
        for t, i in self.taskcla:
            x_ = self.classifier[t](x, print_var, sample)

            if print_var and isinstance(x_, list):
                # Handle variance output for uncertainty estimation
                res_double[0][t] = x_[0]
                res_double[1][t] = x_[1] if len(x_) > 1 else x_[0]
            else:
                try:
                    if isinstance(x_, list):
                        res[t] = x_[0]
                    else:
                        res[t] = x_
                except:
                    pass

        # Return based on flags
        if z_flag:
            return z

        if print_var:
            # Return log softmax for variance analysis
            return torch.nn.functional.log_softmax(res_double, dim=3)
        else:
            # Standard return for training/testing
            return torch.nn.functional.log_softmax(res, dim=2)


def Net(args):
    """Factory function for creating RCB Bayesian MLP"""
    return BayesianMLP(args)