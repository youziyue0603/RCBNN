import torch
import numpy as np
from .FC import BayesianLinear


class BayesianMLP(torch.nn.Module):
    
    def __init__(self, args):
        super(BayesianMLP, self).__init__()

        ncha,size,_= args.inputsize
        self.taskcla= args.taskcla
        self.samples = args.samples
        self.device = args.device
        self.sbatch = args.sbatch
        self.init_lr = args.lr
        self.print_val = args.print_val
        # dim=60  #100k
        # dim=1200
        dim=args.nhid
        nlayers=args.nlayers
        self.fc1 = BayesianLinear(ncha*size*size, dim, args)
        if nlayers==2:
            self.fc2 = BayesianLinear(dim, dim, args)

        self.classifier = torch.nn.ModuleList()
        for t,n in self.taskcla:  # n n分类， t task编号
            self.classifier.append(BayesianLinear(dim, n, args))
        # 生成两个5分类classifier

    def prune(self,mask_modules):
        for module, mask in mask_modules.items():
            module.prune_module(mask)

    # [batch, 32, 32, c]
    def forward(self, x, weights_last, print_var=False, sample=False, z_flag=False):
        x = x.view(x.size(0),-1)
        x = self.fc1(x,weights_last[:2], False, sample)
        if len(x) == 2:
            x = torch.nn.functional.relu(x[0])
        else:
            x = torch.nn.functional.relu(x)
        z = x.clone()
        y=[] #[outforcls1, outforcls2]
        y_var = []
        for t,i in self.taskcla: # t: 0, 1 ; i: 5, 5
            x_ = self.classifier[t](x, weights_last[2:], print_var, sample)
            if len(x_) == 2:
                y.append(x_[0])
                y_var.append(x_[1])
            else:
                y.append(x_) # 2个 5分类 classifiers
        if not z_flag:
            if len(x_) == 2:
                return [[torch.nn.functional.log_softmax(yy, dim=1) for yy in y], y_var]  #softmax后log
            else:
                return [torch.nn.functional.log_softmax(yy, dim=1) for yy in y]  #
        else:
            return z

def Net(args):
    return BayesianMLP(args)



