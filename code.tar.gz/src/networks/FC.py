import torch
import torch.nn as nn
import torch.nn.functional as F
from .distributions import VariationalPosterior, Prior



class BayesianLinear(nn.Module):
    '''
    Applies a linear Bayesian transformation to the incoming data: :math:`y = Ax + b`
    Modified for RCB (Rehearsal-based Continual Bayes)
    '''

    def __init__(self, in_features, out_features, args, use_bias=True):
        super(BayesianLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.use_bias = use_bias
        self.device = args.device
        self.rho = args.rho

        # Variational Posterior Distributions
        self.weight_mu = nn.Parameter(torch.empty((out_features, in_features),
                                      device=self.device, dtype=torch.float32).normal_(0., 0.1),requires_grad=True)
        self.weight_rho = nn.Parameter(self.rho + torch.empty((out_features, in_features),
                                      device=self.device, dtype=torch.float32).normal_(0., 0.1),requires_grad=True)
        self.weight = VariationalPosterior(self.weight_mu, self.weight_rho, self.device)

        if self.use_bias:
            self.bias_mu = nn.Parameter(torch.empty((out_features),
                                      device=self.device, dtype=torch.float32).normal_(0., 0.1),requires_grad=True)
            self.bias_rho = nn.Parameter(self.rho + torch.empty(out_features,
                                      device=self.device, dtype=torch.float32).normal_(0., 0.1),requires_grad=True)
            self.bias = VariationalPosterior(self.bias_mu, self.bias_rho, self.device)
        else:
            self.register_parameter('bias', None)

        # Prior Distributions
        self.weight_prior = Prior(args)
        if self.use_bias:
            self.bias_prior = Prior(args)

        # Initialize log prior and log posterior
        self.log_prior = 0
        self.log_variational_posterior = 0

        # RCB pruning support
        self.mask_flag = False


    def prune_module(self, mask):
        """RCB pruning functionality"""
        self.mask_flag = True
        self.pruned_weight_mu = self.weight_mu.data.clone().mul_(mask).to(self.device)
        self.pruned_weight_rho = self.weight_rho.data.clone().mul_(mask).to(self.device)


    def forward(self, input, print_var=False, sample=False, calculate_log_probs=True):
        """
        Forward pass for RCB
        Args:
            input: Input tensor
            print_var: Whether to return variance information
            sample: Whether to sample from posterior (True for training/uncertainty estimation)
            calculate_log_probs: Whether to calculate log probabilities for ELBO
        """
        if self.mask_flag:
            # Use pruned weights if available
            self.weight = VariationalPosterior(self.pruned_weight_mu, self.pruned_weight_rho, self.device)

        if self.training or sample:
            # Sample from posterior for training or uncertainty estimation
            weight = self.weight.sample()
            bias = self.bias.sample() if self.use_bias else None
        else:
            # Use mean for inference (can also sample for uncertainty)
            weight = self.weight.sample()  # RCB: Always sample for uncertainty
            bias = self.bias.sample() if self.use_bias else None

        if self.training or calculate_log_probs:
            # Calculate ELBO components
            if self.use_bias:
                self.log_prior = self.weight_prior.log_prob(weight) + self.bias_prior.log_prob(bias)
                self.log_variational_posterior = self.weight.log_prob(weight) + self.bias.log_prob(bias)
            else:
                self.log_prior = self.weight_prior.log_prob(weight)
                self.log_variational_posterior = self.weight.log_prob(weight)
        else:
            # For evaluation, still calculate for consistency
            if self.use_bias:
                self.log_prior = self.weight_prior.log_prob(weight) + self.bias_prior.log_prob(bias)
                self.log_variational_posterior = self.weight.log_prob(weight) + self.bias.log_prob(bias)
            else:
                self.log_prior = self.weight_prior.log_prob(weight)
                self.log_variational_posterior = self.weight.log_prob(weight)

        # Linear transformation
        act_mu = F.linear(input, weight, bias)

        if not print_var:
            return act_mu
        else:
            # Return variance information for RCB uncertainty estimation
            bias_var = None
            self.W_sigma = torch.log1p(torch.exp(self.weight_rho))
            act_var = 1e-16 + F.linear(input ** 2, self.W_sigma ** 2, bias_var)
            return [act_mu, act_var]