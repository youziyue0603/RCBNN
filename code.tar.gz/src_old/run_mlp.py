import sys, os, argparse, time
import numpy as np
import torch
import utils
from datetime import datetime
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
tstart = time.time()

# Arguments
parser = argparse.ArgumentParser(description='xxx')
parser.add_argument('--seed', default=0, type=int, help='(default=%(default)d)')
parser.add_argument('--device', default='cuda:0', type=str, help='gpu id')
parser.add_argument('--experiment', default='pmnist', type=str, required=False,
                    choices=['mnist2', 'mnist5', 'pmnist', 'cifar', 'mixture'])
parser.add_argument('--approach', default='ucb', type=str, help='acl')
parser.add_argument('--data_path', default='../data/', type=str, help='gpu id')

# Training parameters
parser.add_argument('--output', default='', type=str, help='')
parser.add_argument('--checkpoint_dir', default='../checkpoints/', type=str, help='')
parser.add_argument('--nepochs', default=20, type=int, help='')  # 200
parser.add_argument('--sbatch', default=128, type=int, help='')
parser.add_argument('--lr', default=0.01, type=float, help='')  # use 0.3 for non-mnist datasets 0.01 for mnist
parser.add_argument('--nlayers', default=1, type=int, help='')
parser.add_argument('--nhid', default=200, type=int, help='')  # 1200
parser.add_argument('--parameter', default='', type=str, help='')
# UCB HYPER-PARAMETERS
parser.add_argument('--samples', default='5', type=int, help='Number of Monte Carlo samples')
parser.add_argument('--rho', default='-3', type=float, help='Initial rho')
parser.add_argument('--sig1', default='0.0', type=float, help='STD foor the 1st prior pdf in scaled mixture Gaussian')
parser.add_argument('--sig2', default='6.0', type=float, help='STD foor the 2nd prior pdf in scaled mixture Gaussian')
parser.add_argument('--pi', default='0.25', type=float, help='weighting factor for prior')
parser.add_argument('--arch', default='mlp', type=str, help='Bayesian Neural Network architecture')
parser.add_argument('--resume', default='no', type=str, help='resume?')  # load params
parser.add_argument('--sti', default=0, type=int, help='starting task?')

parser.add_argument('--print_val', default=False, type=bool, help='starting task?')
parser.add_argument('--replay', default=True, type=bool, help='starting task?')
parser.add_argument('--ncls', default=10, type=bool, help='ncls')
parser.add_argument('--tasks', default=10, type=bool, help='ntasks')  # DIDN'T
parser.add_argument('--randsamp', default=False, type=bool, help='random sampling for replay')
parser.add_argument('--high_var', default=False, type=bool, help='is high var?')
parser.add_argument('--interval', default=True, type=bool, help='interval?')
parser.add_argument('--ratio', default=0.01, type=float, help='how many old tasks')
args = parser.parse_args()
utils.print_arguments(args)

########################################################################################################################

# Seed
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(args.seed)
    # torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# args.cuda = not args.no_cuda and torch.cuda.is_available()
args.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

print('Using device:', args.device)
checkpoint = utils.make_directories(args)
args.checkpoint = checkpoint
print()

# Args -- Experiment
if args.experiment == 'mnist2':
    from dataloaders import mnist2 as dataloader
elif args.experiment == 'mnist5':
    from dataloaders import mnist5 as dataloader
elif args.experiment == 'pmnist':
    from dataloaders import pmnist as dataloader
elif args.experiment == 'cifar':
    from dataloaders import cifar as dataloader
elif args.experiment == 'mixture':
    from dataloaders import mixture as dataloader

# Args -- Approach
if args.approach == 'ucb':
    from approaches import ucb_mlp as approach

# Args -- Network
if args.experiment == 'mnist2' or args.experiment == 'pmnist' or args.experiment == 'mnist5':
    from networks import mlp_ucb as network
else:
    from networks import resnet_ucb as network

print()
print("Starting this run on :")
print(datetime.now().strftime("%Y-%m-%d %H:%M"))

# Load
print('Load data...')
data, taskcla, inputsize = dataloader.get(data_path=args.data_path, seed=args.seed, fixed_order=True)
print('Input size =', inputsize, '\nTask info =', taskcla) # taskcla [(0, 5), (1, 5)] inpursize [1, 28, 28]
args.num_tasks = len(taskcla) # 2 tasks
args.inputsize, args.taskcla = inputsize, taskcla

# Inits
print('Inits...')
model = network.Net(args).to(args.device)

print('-' * 100)
appr = approach.Appr(model, args=args)
print('-' * 100)

# args.output=os.path.join(args.results_path, datetime.now().strftime("%d-%m-%Y-%H-%M-%S"))
print('-' * 100)

# load param
if args.resume == 'yes':
    # checkpoint = torch.load(os.path.join(args.checkpoint, 'model_{}.pth.tar'.format(args.sti)))
    checkpoint = torch.load(str('/mnt/6faed242-81e6-4dae-a66f-77b750a0b1c9/workspace/yushuo/workspace/UCB/checkpoints/pmnist_ucb_high_dep_10samples_unfinished/' + 'model_{}.pth.tar'.format(args.sti)))
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device=args.device)
else:
    args.sti = 0

# Loop tasks
acc = np.zeros((len(taskcla), len(taskcla)), dtype=np.float32)
lss = np.zeros((len(taskcla), len(taskcla)), dtype=np.float32)

weights_last = torch.tensor([0, 1, 1, 1]).to(args.device)  # how to init
loss_list = []
sample_buffer = []
Loss_2 = torch.zeros((4, int(args.nepochs) * int(args.num_tasks)))
Loss_2_T = torch.zeros((2, int(args.nepochs) * int(args.num_tasks)))
# R_IDX = torch.zeros(0).type(torch.long).to(args.device)
R_IDX = torch.ones((args.tasks, 60000)).type(torch.long).to(args.device)
for t, ncla in taskcla[args.sti:]:
    print('*' * 100)
    print('Task {:2d} ({:s})'.format(t, data[t]['name']))  # Task  0 (pmnist-0)
    print('*' * 100)
    if args.approach == 'joint':
        # Get data. We do not put it to GPU
        if t == 0:
            xtrain = data[t]['train']['x']
            ytrain = data[t]['train']['y']
            xvalid = data[t]['valid']['x']
            yvalid = data[t]['valid']['y']
            task_t = t * torch.ones(xtrain.size(0)).int()
            task_v = t * torch.ones(xvalid.size(0)).int()
            task = [task_t, task_v]
        else:
            xtrain = torch.cat((xtrain, data[t]['train']['x']))
            ytrain = torch.cat((ytrain, data[t]['train']['y']))
            xvalid = torch.cat((xvalid, data[t]['valid']['x']))
            yvalid = torch.cat((yvalid, data[t]['valid']['y']))
            task_t = torch.cat((task_t, t * torch.ones(data[t]['train']['y'].size(0)).int()))
            task_v = torch.cat((task_v, t * torch.ones(data[t]['valid']['y'].size(0)).int()))
            task = [task_t, task_v]
    elif args.replay:
        clock1 = time.time()
        if t == 0:
            # Get data
            xtrain = data[t]['train']['x'].to(args.device)
            xtrain_var = xtrain.to(args.device)
            ytrain = data[t]['train']['y'].to(args.device)
            xvalid = data[t]['valid']['x'].to(args.device)
            yvalid = data[t]['valid']['y'].to(args.device)
            task_t = t * torch.ones(xtrain.size(0)).int().to(args.device)
            task_v = t * torch.ones(xvalid.size(0)).int().to(args.device)
            task = torch.cat((task_t, task_v)).to(args.device)

        else:  # to-do: add previous task samples
            xtrain = data[t]['train']['x'].to(args.device)
            ytrain = data[t]['train']['y'].to(args.device)
            task_t = t * torch.ones(data[t]['train']['y'].size(0)).int().to(args.device)
            for i in range(0, t):
              # import pdb; pdb.set_trace()
              xtrain = torch.cat((xtrain, data[i]['train']['x'][R_IDX[i]][sample_buffer[i]].to(args.device))).to(args.device)
              ytrain = torch.cat((ytrain, data[i]['train']['y'][R_IDX[i]][sample_buffer[i]].to(args.device))).to(args.device)
              task_t = torch.cat((task_t, i * torch.ones(data[i]['train']['y'][R_IDX[i]][sample_buffer[i]].size(0)).int().to(args.device))).to(args.device)

            xtrain_var = data[t]['train']['x'].to(args.device)
            xvalid = data[t]['valid']['x'].to(args.device)
            yvalid = data[t]['valid']['y'].to(args.device)
            task_v = t * torch.ones(data[t]['valid']['y'].size(0)).int().to(args.device)
        clock2 = time.time()

    else:
        # Get data
        xtrain = data[t]['train']['x'].to(args.device)
        ytrain = data[t]['train']['y'].to(args.device)
        xvalid = data[t]['valid']['x'].to(args.device)
        yvalid = data[t]['valid']['y'].to(args.device)
        xtrain_var = xvalid
        task = t
        task_t = t * torch.ones(xtrain.size(0)).int().to(args.device)
        task_v = t * torch.ones(xvalid.size(0)).int().to(args.device)

    # Train
    Loss1Tsk,Loss1Tsk_T = appr.train(task_t, task_v, xtrain, ytrain, xvalid, yvalid, loss_list)
    Loss_2[:, int(args.nepochs)*t: int(args.nepochs)*(t+1)] = Loss1Tsk
    Loss_2_T[:, int(args.nepochs)*t: int(args.nepochs)*(t+1)] = Loss1Tsk_T

    # Test
    for u in range(t + 1):
        xtest = data[u]['test']['x'].to(args.device)
        ytest = data[u]['test']['y'].to(args.device)
        task_test = u * torch.ones(data[t]['test']['y'].size(0)).int().to(args.device)
        test_loss, test_acc, fail_idx, _ = appr.eval(task_test, xtest, ytest  , debug=True)
        test_loss *= 100000
        print('>>> Test on task {:2d} - {:15s}: loss={:.3f}, acc={:5.3f}% <<<'.format(u, data[u]['name'], test_loss,   100 * test_acc))
        acc[t, u] = test_acc
        lss[t, u] = test_loss

    # Save
    print('Save at ' + args.checkpoint)
    np.savetxt(os.path.join(args.checkpoint, '{}_{}_{}.txt'.format(args.experiment, args.approach, args.seed)), acc,
               '%.5f')

    #Test for replay
    _, _, fail_idx1, _= appr.eval(task_t[:60000],xtrain[:60000], ytrain[:60000], debug=True)
    if not fail_idx1:
        print('All correctly predicted')
    fail_idx_offset1 = []
    for i in range(len(fail_idx1)):
        fail_idx_offset1 += [fail_idx1[i][0] + 128 * i]
    tmp1 = torch.zeros(0)
    for i in fail_idx_offset1:
        tmp1 = torch.cat((tmp1, i.detach().cpu()))
    tmp1 = tmp1.clone().type(torch.long).to(args.device)
    # import pdb; pdb.set_trace()
    r_idx = torch.ones(60000, dtype=torch.bool).to(args.device)
    r_idx[tmp1] = False
    R_IDX[t] = r_idx
    
        #Replay
    if args.replay:
        pred_var_mean = appr.eval_var(task_t[:60000][r_idx], xtrain_var[r_idx], ytrain[:60000][r_idx])
        var_len = 60000
        _, order = pred_var_mean.sort(descending=args.high_var)  # from big to small
        if args.randsamp:
          order = torch.randint(0, var_len-len(tmp1), (int(var_len * (args.ratio)), ))
        else:
          order = order[:int(var_len*args.ratio)]
        if args.interval:
            _, order = pred_var_mean.sort(descending=False)  # from big to small
            hist_tmp = torch.histc(pred_var_mean, bins=100, min=0)
            mid_bin_num = torch.where(hist_tmp == max(hist_tmp))[0]  # 两个相同的峰值
            peak_var = (mid_bin_num / 100) * (max(pred_var_mean) - min(pred_var_mean)) + min(pred_var_mean)
            peak_var_clone = torch.mean(peak_var) * torch.ones_like(pred_var_mean)
            var_difference = abs(peak_var_clone - pred_var_mean)
            peakIdxOrder = torch.where(order == torch.argmin(var_difference))[0]
            peakOffset = int(var_len * args.ratio / 2)
            order = order[peakIdxOrder - peakOffset: peakIdxOrder + peakOffset]
            # plot_intersection(task_t, xtrain_var, ytrain)

        # unique_num = torch.unique(torch.cat((order_in, order_in_p))).size()[0]
        # print((2 * order_in.size()[0] - unique_num) / order_in.size()[0])
        sample_buffer.append(order)
        
    # #Replay
    # if args.replay:
    #     pred_var_mean = appr.eval_var(task_t[:60000], xtrain_var, ytrain[:60000])
    #     var_len = 60000
    #     _, order = pred_var_mean.sort(descending=args.high_var)  # from big to small
    #     if args.randsamp:
    #       order = torch.randint(0, var_len, (int(var_len * (args.ratio)), ))
    #     else:
    #       order = order[:int(var_len*args.ratio)]
    #     if args.interval:
    #         _, order = pred_var_mean.sort(descending=False)  # from big to small
    #         hist_tmp = torch.histc(pred_var_mean, bins=100, min=0)
    #         mid_bin_num = torch.where(hist_tmp == max(hist_tmp))[0]  # 两个相同的峰值
    #         peak_var = (mid_bin_num / 100) * (max(pred_var_mean) - min(pred_var_mean)) + min(pred_var_mean)
    #         peak_var_clone = torch.mean(peak_var) * torch.ones_like(pred_var_mean)
    #         var_difference = abs(peak_var_clone - pred_var_mean)
    #         peakIdxOrder = torch.where(order == torch.argmin(var_difference))[0]
    #         peakOffset = int(var_len * args.ratio / 2)
    #         order = order[peakIdxOrder - peakOffset: peakIdxOrder + peakOffset]
    #         # plot_intersection(task_t, xtrain_var, ytrain)

    #     # unique_num = torch.unique(torch.cat((order_in, order_in_p))).size()[0]
    #     # print((2 * order_in.size()[0] - unique_num) / order_in.size()[0])
    #     sample_buffer.append(order)


    # pred_var = appr.get_var(task_t, xtrain_var, ytrain, xvalid, yvalid, loss_list)
    # import pdb; pdb.set_trace()
    #
    # pred_var_mean = appr.eval_var(task_t[:60000], xtrain_var, ytrain[:60000])
    # var_len = 60000
    # _, order = pred_var_mean.sort(descending = args.high_var)  # from big to small
    # if args.randsamp:
    #   order = torch.randint(0, var_len, (int(var_len * (args.ratio)), ))
    # else:
    #   order = order[:int(var_len*args.ratio)]
    # sample_buffer.append(order)

utils.print_log_acc_bwt(args, acc, lss)
print('[Elapsed time = {:.1f} h]'.format((time.time() - tstart) / (60 * 60)))


saveResT = np.array(Loss_2_T)
np.savetxt('npresultT_2mlp.txt',saveResT)

import matplotlib.pyplot as plt
import numpy as np

titles_ = ['nll loss of training samples', 'kld loss of training samples', 'nll loss of valid samples', 'pr loss of valid samples']

f = open('npresultT_2mlp.txt')
lines = f.readlines()
titles = ['kld loss of training samples', 'nll loss of training samples']
for i in range(2):
    plt.title(titles[i])
    plt.plot(np.arange(len(lines[i].split())), [float(_) for _ in lines[i].split()])
    plt.savefig(titles[i] + '.jpg')
    plt.show()

# a = np.arange(1878)
# tmp = np.array(loss_list)
# tmp = tmp.reshape((-1,3))

# # import pdb; pdb.set_trace()
# plt.plot(np.arange(len(tmp[:, 0])), tmp[:, 0], 'orange')
# plt.title('post');
# plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/' + args.experiment+ 'post_fuk.png')
# plt.show()
#
# plt.plot(np.arange(len(tmp[:, 1])), tmp[:, 1], 'orange')
# plt.title('prior')
# plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/'+ args.experiment+ 'prior_fuk.png')
# plt.show()
#
# plt.plot(np.arange(len(tmp[:, 2])), tmp[:, 2], 'orange')
# plt.ylim(0,600)
# # tmp_ = tmp[:, 2][4:]
# # plt.plot(np.arange(len(tmp[:, 2])), tmp[:, 2])
# # plt.plot(np.arange(len(tmp[:,2])), tmp[:, 2]); plt.title('nll'); plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/' + args.experiment+ 'nll_c_all_w1_w2.png')
#
#
# plt.title('nll')
# plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/' + args.experiment+ 'nll_fuk.png')
# plt.show()
#import pdb; pdb.set_trace()        
