import sys, os, argparse, time
import numpy as np
import torch
import utils
from datetime import datetime
import seaborn as sns
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
tstart = time.time()


# Arguments
parser = argparse.ArgumentParser(description='xxx')
parser.add_argument('--seed', default=0, type=int, help='(default=%(default)d)')
parser.add_argument('--device', default='cuda:0', type=str, help='gpu id')
parser.add_argument('--experiment', default='cifar', type=str, required=False,
                    choices=['mnist2', 'mnist5', 'pmnist', 'cifar', 'mixture'])
parser.add_argument('--approach', default='ucb', type=str, help='acl')
parser.add_argument('--data_path', default='../data/', type=str, help='gpu id')

# Training parameters
parser.add_argument('--output', default='', type=str, help='')
parser.add_argument('--checkpoint_dir', default='../checkpoints/', type=str, help='')
parser.add_argument('--nepochs', default=1, type=int, help='')  # 200
parser.add_argument('--sbatch', default=128, type=int, help='')
parser.add_argument('--lr', default=0.3, type=float, help='')  # use 0.3 for non-mnist datasets 0.01 for mnist
parser.add_argument('--nlayers', default=1, type=int, help='')
parser.add_argument('--nhid', default=600, type=int, help='')  # 1200
parser.add_argument('--parameter', default='', type=str, help='')
parser.add_argument('--optimizer', default='SGD', type=str, help='',choices=['SGD', 'ADAM'])

# UCB HYPER-PARAMETERS
parser.add_argument('--samples', default='5', type=int, help='Number of Monte Carlo samples')
parser.add_argument('--rho', default='-3', type=float, help='Initial rho')
parser.add_argument('--sig1', default='-1.5', type=float, help='STD foor the 1st prior pdf in scaled mixture Gaussian')
parser.add_argument('--sig2', default='6.0', type=float, help='STD foor the 2nd prior pdf in scaled mixture Gaussian')
parser.add_argument('--pi', default='1', type=float, help='weighting factor for prior')
parser.add_argument('--arch', default='mlp', type=str, help='Bayesian Neural Network architecture')
parser.add_argument('--resume', default='no', type=str, help='resume?')  # load params
parser.add_argument('--sti', default=0, type=int, help='starting task?')

parser.add_argument('--print_val', default=False, type=bool, help='starting task?')
parser.add_argument('--joint', default=False, type=bool, help='joint training?')
parser.add_argument('--replay', default=True, type=bool, help='starting task?')
parser.add_argument('--ncls', default=2, type=bool, help='ncls')  # DIDN'T
parser.add_argument('--tasks', default=5, type=bool, help='ntasks')  # DIDN'T
parser.add_argument('--nsamples', default=9000, type=bool, help='num of samples')  # DIDN'T
parser.add_argument('--randsamp', default=False, type=bool, help='random sampling for replay')
parser.add_argument('--high_var', default=False, type=bool, help='is high var?')
parser.add_argument('--interval', default=True, type=bool, help='interval?')
parser.add_argument('--ratio', default=0.01, type=float, help='how many old tasks')
args = parser.parse_args()
utils.print_arguments(args)

########################################################################################################################

# Seed
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(args.seed)
    # torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# args.cuda = not args.no_cuda and torch.cuda.is_available()
args.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

print('Using device:', args.device)
checkpoint = utils.make_directories(args)
args.checkpoint = checkpoint
print()

# Args -- Experiment
if args.experiment == 'mnist2':
    from dataloaders import mnist2 as dataloader
elif args.experiment == 'mnist5':
    from dataloaders import mnist5 as dataloader
elif args.experiment == 'pmnist':
    from dataloaders import pmnist as dataloader
elif args.experiment == 'cifar':
    from dataloaders import cifar as dataloader
elif args.experiment == 'mixture':
    from dataloaders import cifar as dataloader
elif args.experiment == 'cifar100':
    from dataloaders import cifar100 as dataloader

# Args -- Approach
if args.approach == 'ucb':
    from approaches import ucb as approach

# Args -- Network
if args.experiment == 'mnist2' or args.experiment == 'pmnist' or args.experiment == 'mnist5':
    from networks import mlp_ucb as network
else:
    from networks import resnet_ucb as network

########################################################################################################################
print()
print("Starting this run on :")
print(datetime.now().strftime("%Y-%m-%d %H:%M"))

# Load
print('Load data...')
data, taskcla, inputsize = dataloader.get(data_path=args.data_path, seed=args.seed, fixed_order=True)
# for key in data:
#     if key != 'ncla':
#         data[key]['train']['x'] = data[key]['train']['x'][:500]
#         data[key]['train']['y'] = data[key]['train']['y'][:500]
#         data[key]['test']['x'] = data[key]['test']['x'][:500]
#         data[key]['test']['y'] = data[key]['test']['y'][:500]
#         data[key]['valid']['x'] = data[key]['valid']['x'][:500]
#         data[key]['valid']['y'] = data[key]['valid']['y'][:500]

print('Input size =', inputsize, '\nTask info =', taskcla) # taskcla [(0, 5), (1, 5)] inpursize [1, 28, 28]
args.num_tasks = len(taskcla) # 2 tasks
args.inputsize, args.taskcla = inputsize, taskcla

# Inits
print('Inits...')
model = network.Net(args).to(args.device)

print('-' * 100)
appr = approach.Appr(model, args=args)
print('-' * 100)

# args.output=os.path.join(args.results_path, datetime.now().strftime("%d-%m-%Y-%H-%M-%S"))
print('-' * 100)

if args.resume == 'yes':
    checkpoint = torch.load(os.path.join(args.checkpoint, 'model_{}.pth.tar'.format(args.sti)))
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device=args.device)
else:
    args.sti = 0

# Loop tasks
acc = np.zeros((len(taskcla), len(taskcla)), dtype=np.float32)
lss = np.zeros((len(taskcla), len(taskcla)), dtype=np.float32)
z_list = np.zeros((len(taskcla), len(taskcla)), dtype=np.float32)

weights_last = torch.tensor([0, 1, 1, 1]).to(args.device)  # how to init
loss_list = []
sample_buffer = []
Loss_2 = torch.zeros((4, int(args.nepochs) * int(args.num_tasks)))
Loss_2_T = torch.zeros((2, int(args.nepochs) * int(args.num_tasks)))
# R_IDX = torch.zeros(0).type(torch.long).to(args.device)
R_IDX = torch.ones((args.tasks, args.nsamples)).type(torch.long).to(args.device)

def plot_intersection(task_t, xtrain_var, ytrain):
    order_e = []
    order_i = []
    for i in range(2):
        pred_var_mean = appr.eval_var(task_t[:9000], xtrain_var, ytrain[:9000])
        # pred_var_mean = abs(pred_var[:, 0]) + abs(pred_var[:, 1]) # pred_var.mean(1)
        # import pdb; pdb.set_trace()
        var_len = len(pred_var_mean)
        _, order = pred_var_mean.sort(descending=False)  # from big to small
        if args.randsamp:
            order = torch.randint(0, var_len, (int(var_len * (args.ratio)),))
        else:
            order_e.append(order[:int(var_len * args.ratio)])  # 1 3
            order_e.append(order[-int(var_len * args.ratio):])  # 2 4

            # order_i.append(order[
            #                int(pred_var_mean.size()[0] / 2) - int(var_len * args.ratio / 2):int(
            #                    pred_var_mean.size()[0] / 2) + int(
            #                    var_len * args.ratio / 2)])

            hist_tmp = torch.histc(pred_var_mean, bins=100, min=0)
            mid_bin_num = torch.where(hist_tmp == max(hist_tmp))[0]
            peak_var = (mid_bin_num / 100) * (max(pred_var_mean) - min(pred_var_mean)) + min(pred_var_mean)
            peak_var_clone = peak_var * torch.ones_like(pred_var_mean)
            var_difference = abs(peak_var_clone - pred_var_mean)
            peakIdxOrder = torch.where(order == torch.argmin(var_difference))[0]
            peakOffset = int(var_len * args.ratio / 2)
            order_i.append(order[peakIdxOrder - peakOffset: peakIdxOrder + peakOffset])



    tmp = torch.unique(torch.cat((order_i[0], order_i[1]))).size()[0]
    mid_rate = str(100 * ((2 * args.ratio * order.size()[0] - tmp) / (args.ratio * order.size()[0])))[:4] + '%'
    print('mid var samples Intersection rate: ' + mid_rate)
    tmp = torch.unique(torch.cat((order_e[0], order_e[2]))).size()[0]
    low_rate = str(100 * ((2 * args.ratio * order.size()[0] - tmp) / (args.ratio * order.size()[0])))[:4] + '%'
    print('low var samples Intersection rate: ' + low_rate)
    tmp = torch.unique(torch.cat((order_e[1], order_e[3]))).size()[0]
    high_rate = str(100 * ((2 * args.ratio * order.size()[0] - tmp) / (args.ratio * order.size()[0])))[:4] + '%'
    print('high var samples Intersection rate: ' + high_rate)

    idx_orde_in_ord = torch.zeros_like(order_e[0]).to(args.device)
    for i in range(order_e[0].size()[0]):
        idx_orde_in_ord[i] = torch.where(order == order_e[0][i])[0]
    sns_plot3 = sns.distplot(pred_var_mean.detach().cpu(), rug=True, color='y')
    fig3 = sns_plot3.get_figure()
    plt.title('PDF_all of Task ' + str(t))
    plt.savefig('Results/Intersection_PDF_all_samples after task_' + str(t) + '.jpg')
    plt.show()
    plt.close()
    '''low'''
    sns_plot3 = sns.distplot(pred_var_mean[order_e[2]].detach().cpu(), rug=True, color='b')
    fig3 = sns_plot3.get_figure()
    plt.title('low var samples of Task ' + str(t))
    # plt.show()
    # plt.close()
    plt.legend(['Intersection Rate: ' + low_rate])
    sns_plot3 = sns.distplot(pred_var_mean[order_e[0]].detach().cpu(), rug=True, color='#98F5FF')
    fig3 = sns_plot3.get_figure()
    plt.title('low var samples of Task ' + str(t))
    plt.savefig('Results/Intersection_PDF_low_samples after task_' + str(t) + '.jpg', dpi=200)
    plt.show()
    plt.close()
    '''high'''
    sns_plot3 = sns.distplot(pred_var_mean[order_e[3]].detach().cpu(), rug=True, color='#CD6600')
    fig3 = sns_plot3.get_figure()
    plt.title('high var samples of Task ' + str(t))
    # plt.show()
    # plt.close()
    plt.legend(['Intersection Rate: ' + high_rate])
    sns_plot3 = sns.distplot(pred_var_mean[order_e[1]].detach().cpu(), rug=True, color='#FF8C00')
    fig3 = sns_plot3.get_figure()
    plt.title('low var samples of Task ' + str(t))
    plt.savefig('Results/Intersection_PDF_high_samples after task_' + str(t) + '.jpg', dpi=200)
    plt.show()
    plt.close()
    '''mid'''
    sns_plot3 = sns.distplot(pred_var_mean[order_i[1]].detach().cpu(), rug=True, color='g')
    fig3 = sns_plot3.get_figure()
    plt.title('mid var samples of Task ' + str(t))
    # plt.show()
    # plt.close()
    sns_plot3 = sns.distplot(pred_var_mean[order_i[0]].detach().cpu(), rug=True, color='#BDFCC9')
    fig3 = sns_plot3.get_figure()
    plt.title('mid var samples of Task ' + str(t))
    plt.legend(['Intersection Rate: ' + mid_rate])
    plt.savefig('Results/Intersection_PDF_mid_samples after task_' + str(t) + '.jpg', dpi=200)
    plt.show()
    plt.close()
    return

for t, ncla in taskcla[args.sti:]:
    print('*' * 100)
    print('Task {:2d} ({:s})'.format(t, data[t]['name']))  # Task  0 (pmnist-0)
    print('*' * 100)

    weights_last[2] = torch.tensor(1).to(args.device)
    weights_last[3] = torch.tensor(1).to(args.device)

    if args.joint:
        xtrain = torch.zeros(0).to(args.device)
        ytrain = torch.zeros(0).to(args.device)
        xvalid = torch.zeros(0).to(args.device)
        yvalid = torch.zeros(0).to(args.device)
        task_t = torch.zeros(0).to(args.device)
        task_v = torch.zeros(0).to(args.device)

        for t_ in range(5):
            xtrain = torch.cat((xtrain, data[t_]['train']['x'].to(args.device)))
            ytrain = torch.cat((ytrain, data[t_]['train']['y'].to(args.device))).long()
            xvalid = torch.cat((xvalid, data[t_]['valid']['x'].to(args.device)))
            yvalid = torch.cat((yvalid, data[t_]['valid']['y'].to(args.device))).long()
            task_t = torch.cat((task_t, t_ * torch.ones(data[t_]['train']['y'].size(0)).int().to(args.device))).long()
            task_v = torch.cat((task_v, t_ * torch.ones(data[t_]['valid']['y'].size(0)).int().to(args.device))).long()
            # task = torch.cat((task_t, task_v)).to(args.device)

        # # Get data. We do not put it to GPU
        # if t == 0:
        #     xtrain = data[t]['train']['x']
        #     ytrain = data[t]['train']['y']
        #     xvalid = data[t]['valid']['x']
        #     yvalid = data[t]['valid']['y']
        #     task_t = t * torch.ones(xtrain.size(0)).int()
        #     task_v = t * torch.ones(xvalid.size(0)).int()
        #     task = [task_t, task_v]
        # else:
        #     xtrain = torch.cat((xtrain, data[t]['train']['x']))
        #     ytrain = torch.cat((ytrain, data[t]['train']['y']))
        #     xvalid = torch.cat((xvalid, data[t]['valid']['x']))
        #     yvalid = torch.cat((yvalid, data[t]['valid']['y']))
        #     task_t = torch.cat((task_t, t * torch.ones(data[t]['train']['y'].size(0)).int()))
        #     task_v = torch.cat((task_v, t * torch.ones(data[t]['valid']['y'].size(0)).int()))
        #     task = [task_t, task_v]
    else:
        if args.replay:
            if t == 0:
                # Get data
                xtrain = data[t]['train']['x'].to(args.device)
                xtrain_var = xtrain.to(args.device)
                ytrain = data[t]['train']['y'].to(args.device)
                xvalid = data[t]['valid']['x'].to(args.device)
                yvalid = data[t]['valid']['y'].to(args.device)
                task_t = t * torch.ones(xtrain.size(0)).int().to(args.device)
                task_v = t * torch.ones(xvalid.size(0)).int().to(args.device)
                task = torch.cat((task_t, task_v)).to(args.device)
                # task = [task_t, task_v]
            else:  # to-do: add previous task samples
                xtrain = data[t]['train']['x'].to(args.device)#, data[t-1]['train']['x'][sample_buffer[t-1]])).to(args.device)
                ytrain = data[t]['train']['y'].to(args.device)#, data[t-1]['train']['y'][sample_buffer[t-1]])).to(args.device)
                task_t = t * torch.ones(data[t]['train']['y'].size(0)).int().to(args.device)
                for i in range(0, t):
                  xtrain = torch.cat((xtrain, data[i]['train']['x'][sample_buffer[i]].to(args.device))).to(args.device)
                  # import pdb; pdb.set_trace()
                  ytrain = torch.cat((ytrain, data[i]['train']['y'][sample_buffer[i]].to(args.device))).to(args.device)
                  task_t = torch.cat((task_t, i * torch.ones(data[i]['train']['y'][sample_buffer[i]].size(0)).int().to(args.device))).to(args.device)
                xtrain_var = data[t]['train']['x'].to(args.device)
                xvalid = data[t]['valid']['x'].to(args.device)
                yvalid = data[t]['valid']['y'].to(args.device)  # to-do
                task_v = t * torch.ones(data[t]['valid']['y'].size(0)).int().to(args.device)

        else:
            # Get data
            xtrain = data[t]['train']['x'].to(args.device)
            ytrain = data[t]['train']['y'].to(args.device)
            xvalid = data[t]['valid']['x'].to(args.device)
            yvalid = data[t]['valid']['y'].to(args.device)
            xtrain_var = xvalid
            task = t
            task_t = t * torch.ones(xtrain.size(0)).int().to(args.device)
            task_v = t * torch.ones(xvalid.size(0)).int().to(args.device)

    # Train
    Loss1Tsk,Loss1Tsk_T = appr.train(task_t, task_v, xtrain, ytrain, xvalid, yvalid, loss_list)
    Loss_2[:, int(args.nepochs)*t: int(args.nepochs)*(t+1)] = Loss1Tsk
    Loss_2_T[:, int(args.nepochs)*t: int(args.nepochs)*(t+1)] = Loss1Tsk_T
    # appr.train(task_t, task_v, xtrain, ytrain, xvalid, yvalid, loss_list)
    # Loss_2_T.append(Loss1Tsk_T)

    # Test
    if not os.path.exists('Results/'):
        os.makedirs('Results/')

    for u in range(t + 1):
        # print('u:' + str(u))
        xtest = data[u]['test']['x'].to(args.device)
        ytest = data[u]['test']['y'].to(args.device)
        task_test = u * torch.ones(data[u]['test']['y'].size(0)).int().to(args.device)
        test_loss, test_acc, fail_idx, _ = appr.eval(task_test, xtest, ytest, debug=True)
        # test_loss, test_acc, fail_idx = appr.eval(task_v, data[u]['valid']['x'].to(args.device), data[u]['valid']['y'].to(args.device), debug=True)
        print('>>> Test on task {:2d} - {:15s}: loss={:.3f}, acc={:5.3f}% <<<'.format(u, data[u]['name'], test_loss,   100 * test_acc))
        # if t == 1:
        # z_ = appr.check_embedding(u, xtest, ytest, weights_last, debug=True)
        # z_list[t, u] = z_
        acc[t, u] = test_acc
        lss[t, u] = test_loss

        # test_loss *= 100000
        # if t == 10:
        #     # print false samples
        #     fail_idx_offset = []
        #     for i in range(len(fail_idx)):
        #         fail_idx_offset += [fail_idx[i][0] + 128 * i]
        #     tmp = torch.zeros(0)
        #     for i in fail_idx_offset:
        #         tmp = torch.cat((tmp, i.detach().cpu()))
        #
        #     a11 = xtest.permute(0, 2, 3, 1).detach().cpu()[0]
        #     a11 -= torch.min(a11)
        #     a11 /= (torch.max(a11) - torch.min(a11))
        #
        #     # getting the var of the false samples
        #     pred_var_mean = appr.eval_var(task_test, xtest, ytest)
        #     false_sample_var = pred_var_mean[tmp.long()]
        #     false_high_var, high_idx = false_sample_var.topk(9)  # topk
        #     false_high_img = xtest[high_idx].permute(0, 2, 3, 1).detach().cpu()
        #
        #     sns_plot = sns.distplot(false_high_var.detach().cpu(), rug=True, color='g')
        #     fig = sns_plot.get_figure()
        #
        #     plt.title('PDF_printed of Task ' + str(u))
        #     fig.savefig('Results/PDF_printed of Task ' + str(u) + '.jpg')
        #     plt.show()
        #     plt.close()
        #     sns_plot2 = sns.distplot(false_sample_var.detach().cpu(), rug=True)
        #     fig2 = sns_plot2.get_figure()
        #     plt.title('PDF_false samples of Task ' + str(u))
        #     fig2.savefig('Results/PDF_false_samples of Task ' + str(u)+'.jpg', color='r')
        #     plt.show()
        #     plt.close()
        #     sns_plot3 = sns.distplot(pred_var_mean.detach().cpu(), rug=True, color='y')
        #     fig3 = sns_plot3.get_figure()
        #     plt.title('PDF_all of Task ' + str(u))
        #     fig3.savefig('Results/PDF_all of Task ' + str(u) + '.jpg')
        #     plt.show()
        #     plt.close()
        #
        #     img_num = 9 if false_high_img.size()[0] >= 9 else false_high_img.size()[0]
        #     for i in range(img_num):
        #         plt.subplot(331+i)
        #         plt.imshow((false_high_img[i] - torch.min(false_high_img[i])) / (torch.max(false_high_img[i]) - torch.min(false_high_img[i])))  # norm
        #
        #     plt.suptitle('Task ' + str(u) + '- high var samples')
        #     plt.savefig('Results/Task' + str(u) + '-high var samples.jpg')
        #     plt.show()
        #     plt.close()



    # Save
    print('Save at ' + args.checkpoint)
    np.savetxt(os.path.join(args.checkpoint, '{}_{}_{}.txt'.format(args.experiment, args.approach, args.seed)), acc,
               '%.5f')

    #Test for replay
    # _, _, fail_idx1, _= appr.eval(task_t,xtrain, ytrain, debug=True)
    # if not fail_idx1:
    #     print('All correctly predicted')
    # fail_idx_offset1 = []
    # for i in range(len(fail_idx1)):
    #     fail_idx_offset1 += [fail_idx1[i][0] + 128 * i]
    # tmp1 = torch.zeros(0)

    # for i in fail_idx_offset1:
    #     tmp1 = torch.cat((tmp1, i.detach().cpu()))

    # tmp1 = tmp1.clone().type(torch.long).to(args.device)
    # r_idx = torch.ones(9000, dtype=torch.bool).to(args.device)
    # r_idx[tmp1] = False
    # R_IDX[t] = r_idx
    # import pdb; pdb.set_trace()
    #Replay
    if args.replay:
        pred_var_mean, fail_idx1= appr.eval_var(task_t[:9000], xtrain_var, ytrain[:9000])
        pred_var_mean[fail_idx1] = torch.max(pred_var_mean)+1 # torch.inf
        # pred_var_mean = abs(pred_var[:, 0]) + abs(pred_var[:, 1]) # pred_var.mean(1)
        #import pdb; pdb.set_trace()
        var_len = len(pred_var_mean)
        _, order = pred_var_mean.sort(descending=args.high_var)  # from big to small
        if args.randsamp:
          order = torch.randint(0, var_len, (int(var_len * (args.ratio)), ))
          # order = torch.randint(1000, var_len-1000, (int(var_len * (args.ratio)), ))
        else:
          if args.high_var:
            order = order[len(fail_idx1):int(var_len*args.ratio) + len(fail_idx1)]
          else:
            order = order[:int(var_len*args.ratio)]
        if args.interval:
            _, order = pred_var_mean.sort(descending=False)  # from big to small
            # order = order[int(pred_var_mean.size()[0]/2)-int(var_len*args.ratio/2):int(pred_var_mean.size()[0]/2)+int(var_len*args.ratio/2)]
            hist_tmp = torch.histc(pred_var_mean, bins=100, min=0)
            mid_bin_num = torch.where(hist_tmp == max(hist_tmp))[0]  # 两个相同的峰值
            peak_var = (mid_bin_num / 100) * (max(pred_var_mean) - min(pred_var_mean)) + min(pred_var_mean)
            peak_var_clone = torch.mean(peak_var) * torch.ones_like(pred_var_mean)
            var_difference = abs(peak_var_clone - pred_var_mean)
            peakIdxOrder = torch.where(order == torch.argmin(var_difference))[0]
            peakOffset = int(var_len * args.ratio / 2)
            order = order[peakIdxOrder - peakOffset: peakIdxOrder + peakOffset]
            # plot_intersection(task_t, xtrain_var, ytrain)

        # unique_num = torch.unique(torch.cat((order_in, order_in_p))).size()[0]
        # print((2 * order_in.size()[0] - unique_num) / order_in.size()[0])
        sample_buffer.append(order)


        # tmp_b = sample_buffer
        # getting the var of the false samples
        # task_test = t * torch.ones(data[t]['train']['y'].size(0)).int().to(args.device)
        # _, _, fail_idx, _ = appr.eval(task_t[:9000],xtrain[:9000], ytrain[:9000], debug=True)

        # fail_idx_offset = []
        # for i in range(len(fail_idx)):
        #     fail_idx_offset += [fail_idx[i][0] + 128 * i]
        # tmp = torch.zeros(0)
        # for i in fail_idx_offset:
        #     tmp = torch.cat((tmp, i.detach().cpu()))

        ''' TO-DO'''
        # len(set(sample_buffer[0].detach().cpu().numpy()) & set(sample_buffer[2].detach().cpu().numpy()) & set(
        #     sample_buffer[3].detach().cpu().numpy()) & set(sample_buffer[4].detach().cpu().numpy()) & set(
        # #     sample_buffer[1].detach().cpu().numpy()))
        # ''' FOR 9000-9090 '''
        # _, _, fail_idx1, _= appr.eval(task_t,xtrain, ytrain, debug=True)
        # if not fail_idx1:
        #     print('All correctly predicted')
        # fail_idx_offset1 = []
        # for i in range(len(fail_idx1)):
        #     fail_idx_offset1 += [fail_idx1[i][0] + 128 * i]
        # tmp1 = torch.zeros(0)
        # for i in fail_idx_offset1:
        #     tmp1 = torch.cat((tmp1, i.detach().cpu()))
        # # print('&'*100)
        # # print('Wrong Predicted:')
        # # # if tmp1[-1]:
        # # #     print(str(tmp1[-1]))#  + str(tmp1[-5]))
        # # print('&'*100)

        # for data_cls in ['valid', 'train']:
        #     # pred_var_mean_v = torch.zeros(args.tasks, xvalid.size(0))
        #     for h in range(args.tasks):
        #         # import pdb; pdb.set_trace()
        #         pred_var_mean_v, _ = appr.eval_var(h * torch.ones(data[h][data_cls]['x'].size(0)).int().to(args.device),
        #                                         data[h][data_cls]['x'].to(args.device),
        #                                         data[h][data_cls]['y'].to(args.device))
        #         sns_plot2 = sns.distplot(pred_var_mean_v.detach().cpu(), rug=True)
        #         sns_plot2.set_xlim(-0.1,1.25)
        #         fig2 = sns_plot2.get_figure()
        #     plt.title('PDF_previous ' + data_cls + ' samples | after task ' + str(t))
        #     plt.legend(['task0', 'task1', 'task2', 'task3', 'task4'])
        #     plt.savefig('Results/PDF_'+ data_cls + ' samples after task_' + str(t) + '.jpg', color='r')
        #     plt.show()
        #     plt.close()

        # err = []
        # for p in range(t):
        #     err.append('error rate: ' + str(round(100*(torch.where(
        #         9000 * (1 + (p + 1) * args.ratio) > tmp1[torch.where(tmp1 >= 9000 * (1 + p * args.ratio))[0]])[
        #                              0].size()[0] / (9000 * args.ratio)), 2)) + '%')

        #     previous_idx_1 = int(9000 * (p * args.ratio + 1))
        #     pred_var_mean_sub = appr.eval_var(task_t[previous_idx_1:previous_idx_1 + int(9000 * args.ratio)],
        #                                       # 9000-9090
        #                                       xtrain[previous_idx_1:previous_idx_1 + int(9000 * args.ratio)],
        #                                       ytrain[previous_idx_1:previous_idx_1 + int(9000 * args.ratio)])
        #     sns_plot2 = sns.distplot(pred_var_mean_sub.detach().cpu(), rug=True)
        #     fig2 = sns_plot2.get_figure()
        #     plt.legend([err[p]])
        #     plt.title('PDF_previous samples of Task ' + str(p) + ' after task ' + str(t))
        #     fig2.savefig('Results/PDF_previous samples of Task ' + str(p) + ' after task_' + str(t) + '.jpg', color='r')
        #     plt.show()
        #     plt.close()

        # pred_var_mean = appr.eval_var(task_test, xtrain[:9000], ytrain[:9000])
        # false_sample_var = pred_var_mean[tmp.long()]

        # # false_high_var, high_idx = false_sample_var.topk(9)  # topk
        # # false_high_img = xtrain[:9000][high_idx].permute(0, 2, 3, 1).detach().cpu()

        # # sns_plot = sns.distplot(false_high_var.detach().cpu(), rug=True, color='g')
        # # fig = sns_plot.get_figure()
        # # plt.title('PDF_printed of Task ' + str(t))
        # # fig.savefig('Results/PDF_printed of Task ' + str(t) + '.jpg')
        # # plt.show()
        # # plt.close()

        # sns_plot2 = sns.distplot(false_sample_var.detach().cpu(), rug=True)
        # fig2 = sns_plot2.get_figure()
        # plt.title('PDF_false samples of Task ' + str(t))
        # fig2.savefig('Results/PDF_false_samples of Task ' + str(t)+'.jpg', color='r')
        # plt.show()
        # plt.close()

        # sns_plot3 = sns.distplot(pred_var_mean.detach().cpu(), rug=True, color='y')
        # fig3 = sns_plot3.get_figure()
        # plt.title('PDF_all of Task ' + str(t))
        # fig3.savefig('Results/PDF_all of Task ' + str(t) + '.jpg')
        # plt.show()
        # plt.close()

        # # img_num = 9 if false_high_img.size()[0] >= 9 else false_high_img.size()[0]
        # # for i in range(img_num):
        # #     plt.subplot(331+i)
        # #     plt.imshow((false_high_img[i] - torch.min(false_high_img[i])) / (torch.max(false_high_img[i]) - torch.min(false_high_img[i])))  # norm
        # #
        # # plt.suptitle('Task ' + str(t) + '- high var samples')
        # # plt.savefig('Results/Task' + str(t) + '-high var samples.jpg')
        # # plt.show()
        # # plt.close()

    print('-' * 100)


    #
    # # Test
    # if not os.path.exists('Results/'):
    #     os.makedirs('Results/')
    #
    # for u in range(t + 1):
    #     # print('u:' + str(u))
    #     xtest = data[u]['test']['x'].to(args.device)
    #     ytest = data[u]['test']['y'].to(args.device)
    #     task_test = u * torch.ones(data[t]['test']['y'].size(0)).int().to(args.device)
    #     test_loss, test_acc, fail_idx = appr.eval(task_test, xtest, ytest, debug=True)
    #     # test_loss *= 100000
    #     # if t == 10:
    #     #     # print false samples
    #     #     fail_idx_offset = []
    #     #     for i in range(len(fail_idx)):
    #     #         fail_idx_offset += [fail_idx[i][0] + 128 * i]
    #     #     tmp = torch.zeros(0)
    #     #     for i in fail_idx_offset:
    #     #         tmp = torch.cat((tmp, i.detach().cpu()))
    #     #
    #     #     a11 = xtest.permute(0, 2, 3, 1).detach().cpu()[0]
    #     #     a11 -= torch.min(a11)
    #     #     a11 /= (torch.max(a11) - torch.min(a11))
    #     #
    #     #     # getting the var of the false samples
    #     #     pred_var_mean = appr.eval_var(task_test, xtest, ytest)
    #     #     false_sample_var = pred_var_mean[tmp.long()]
    #     #     false_high_var, high_idx = false_sample_var.topk(9)  # topk
    #     #     false_high_img = xtest[high_idx].permute(0, 2, 3, 1).detach().cpu()
    #     #
    #     #     sns_plot = sns.distplot(false_high_var.detach().cpu(), rug=True, color='g')
    #     #     fig = sns_plot.get_figure()
    #     #
    #     #     plt.title('PDF_printed of Task ' + str(u))
    #     #     fig.savefig('Results/PDF_printed of Task ' + str(u) + '.jpg')
    #     #     plt.show()
    #     #     plt.close()
    #     #     sns_plot2 = sns.distplot(false_sample_var.detach().cpu(), rug=True)
    #     #     fig2 = sns_plot2.get_figure()
    #     #     plt.title('PDF_false samples of Task ' + str(u))
    #     #     fig2.savefig('Results/PDF_false_samples of Task ' + str(u)+'.jpg', color='r')
    #     #     plt.show()
    #     #     plt.close()
    #     #     sns_plot3 = sns.distplot(pred_var_mean.detach().cpu(), rug=True, color='y')
    #     #     fig3 = sns_plot3.get_figure()
    #     #     plt.title('PDF_all of Task ' + str(u))
    #     #     fig3.savefig('Results/PDF_all of Task ' + str(u) + '.jpg')
    #     #     plt.show()
    #     #     plt.close()
    #     #
    #     #     img_num = 9 if false_high_img.size()[0] >= 9 else false_high_img.size()[0]
    #     #     for i in range(img_num):
    #     #         plt.subplot(331+i)
    #     #         plt.imshow((false_high_img[i] - torch.min(false_high_img[i])) / (torch.max(false_high_img[i]) - torch.min(false_high_img[i])))  # norm
    #     #
    #     #     plt.suptitle('Task ' + str(u) + '- high var samples')
    #     #     plt.savefig('Results/Task' + str(u) + '-high var samples.jpg')
    #     #     plt.show()
    #     #     plt.close()
    #
    #
    #     print('>>> Test on task {:2d} - {:15s}: loss={:.3f}, acc={:5.3f}% <<<'.format(u, data[u]['name'], test_loss,   100 * test_acc))
    #     # if t == 1:
    #     # z_ = appr.check_embedding(u, xtest, ytest, weights_last, debug=True)
    #     # z_list[t, u] = z_
    #     acc[t, u] = test_acc
    #     lss[t, u] = test_loss
    #
    # # Save
    # print('Save at ' + args.checkpoint)
    # np.savetxt(os.path.join(args.checkpoint, '{}_{}_{}.txt'.format(args.experiment, args.approach, args.seed)), acc,
    #            '%.5f')

utils.print_log_acc_bwt(args, acc, lss)
print('[Elapsed time = {:.1f} h]'.format((time.time() - tstart) / (60 * 60)))

saveRes = np.array(Loss_2)
np.savetxt('npresult.txt',saveRes)

saveResT = np.array(Loss_2_T)
np.savetxt('npresultT.txt',saveResT)

# a = np.arange(1878)
# tmp = np.array(loss_list)
# tmp = tmp.reshape((-1,3))

# # import pdb; pdb.set_trace()
# plt.plot(np.arange(len(tmp[:, 0])), tmp[:, 0], 'orange')
# plt.title('post');
# plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/' + args.experiment+ 'post_fuk.png')
# plt.show()
#
# plt.plot(np.arange(len(tmp[:, 1])), tmp[:, 1], 'orange')
# plt.title('prior')
# plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/'+ args.experiment+ 'prior_fuk.png')
# plt.show()
#
# plt.plot(np.arange(len(tmp[:, 2])), tmp[:, 2], 'orange')
# plt.ylim(0,600)
# # tmp_ = tmp[:, 2][4:]
# # plt.plot(np.arange(len(tmp[:, 2])), tmp[:, 2])
# # plt.plot(np.arange(len(tmp[:,2])), tmp[:, 2]); plt.title('nll'); plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/' + args.experiment+ 'nll_c_all_w1_w2.png')
#
#
# plt.title('nll')
# plt.savefig('/content/drive/MyDrive/researchHub/UCB_modified/' + args.experiment+ 'nll_fuk.png')
# plt.show()
#import pdb; pdb.set_trace()        

#a = 1

