import torch
import numpy as np
from .FC import BayesianLinear


class BayesianMLP(torch.nn.Module):
    
    def __init__(self, args):
        super(BayesianMLP, self).__init__()

        ncha,size,_= args.inputsize
        self.taskcla= args.taskcla
        self.samples = args.samples
        self.device = args.device
        self.sbatch = args.sbatch
        self.init_lr = args.lr
        self.print_val = args.print_val
        self.ncls = args.ncls
        # dim=60  #100k
        # dim=1200
        dim=args.nhid
        nlayers=args.nlayers
        self.fc1 = BayesianLinear(ncha*size*size, dim, args)
        if nlayers==2:
            self.fc2 = BayesianLinear(dim, dim, args)

        self.classifier = torch.nn.ModuleList()
        for t,n in self.taskcla:  # n n分类， t task编号
            self.classifier.append(BayesianLinear(dim, n, args))
        # 生成两个5分类classifier

    def prune(self,mask_modules):
        for module, mask in mask_modules.items():
            module.prune_module(mask)

    # [batch, 32, 32, c]
    def forward(self, x, print_var=False, sample=False, z_flag=False):
        x = x.view(x.size(0),-1)
        res = torch.zeros([self.ncls, x.size()[0], self.taskcla[0][-1]]).to('cuda:0')
        # res_var = torch.zeros([self.ncls, x.size()[0], self.ncls])
        res_double = torch.zeros(([2, self.ncls, x.size()[0], self.taskcla[0][-1]])).to('cuda:0')

        x = self.fc1(x,False, sample)
        if len(x) == 2:
            x = torch.nn.functional.relu(x[0])
        else:
            x = torch.nn.functional.relu(x)
        z = x.clone()
        y=[] #[outforcls1, outforcls2]
        y_var = []
        for t,i in self.taskcla: # t: 0, 1 ; i: 5, 5
            x_ = self.classifier[t](x, print_var, sample)
            if print_var:

                res_double[0][t] = x_[: int(x_.size()[0] / 2)]
                res_double[1][t] = x_[int(x_.size()[0] / 2): ]
            else:
                res[t] = x_
                # y.append(x_) # 2个 5分类 classifiers
        if not z_flag:
            if print_var:
                # return [[torch.nn.functional.log_softmax(yy, dim=1) for yy in y], y_var]  #softmax后log
                return torch.nn.functional.log_softmax(res_double, dim=3)  # list not tensor

            else:
                # for i in range(len(y)):
                #     y[i] = y[i].unsqueeze(0)
                # return [torch.nn.functional.log_softmax(yy, dim=1) for yy in y]  # list not tensor
                return torch.nn.functional.log_softmax(res, dim=2)  # list not tensor

        else:
            return z

def Net(args):
    return BayesianMLP(args)



